# Pronoia：分步骤调研与算法规范

核查日期：2026-10-23。版本：Pronoia 占星选香 2.0。

## 先确定产品边界

这是一种以个人目标为中心的选香仪式。天体位置可以计算；气味偏好需要本人反馈；行星与植物对应属于历史信仰或现代象征。三者不能合并成可验证的“转运功效”。首版没有任何成功概率模型。

本次交付覆盖 10 品牌 × 4 款代表香水、6 项一手心理学研究、17 项香材传统记录。它不是全市场普查或系统综述；后续全线扩库需要逐个版本、地区和改版时间核查。

## 第一步：品牌、系列与香调资料

优先读取品牌官方单品页；同名不同浓度不合并。官网只给关键香调时不补编前中后调。香调是嗅觉描述，不是完整成分表、实际植物含量或单分子清单。强度 1–3、风格与目标标签均为编辑估计。

| 品牌 | 香水 / 版本 | 官方公开香调（中文整理） | 来源 |
| --- | --- | --- | --- |
| L’Artisan Parfumeur 阿蒂仙 | Mûre et Musc · EDT | 关键：黑莓、柠檬、白麝香 | [官方页面](https://www.artisanparfumeur.com/us/en_US/p/mure-et-musc-eau-de-toilette-100ml--000000000065168721) |
| L’Artisan Parfumeur 阿蒂仙 | Passage d’Enfer · EDT | 关键：百合、焚香、白麝香 | [官方页面](https://www.artisanparfumeur.com/us/en_US/p/passage-d-enfer-eau-de-toilette-100ml--000000000065168700) |
| L’Artisan Parfumeur 阿蒂仙 | Premier Figuier · EDT | 关键：无花果叶、无花果、雪松 | [官方页面](https://www.artisanparfumeur.com/us/en_US/p/premier-figuier-eau-de-toilette-100ml--000000000065173232) |
| L’Artisan Parfumeur 阿蒂仙 | La Chasse aux Papillons · EDT | 关键：茉莉、椴树花、橙花 | [官方页面](https://www.artisanparfumeur.com/fr/fr/p/la-chasse-aux-papillons-eau-de-toilette-100-ml--000000000065173187) |
| Le Labo | SANTAL 33 · EDP | 关键：小豆蔻、鸢尾、紫罗兰、檀香、雪松、皮革、麝香 | [官方页面](https://www.lelabofragrances.com/fr/santal-33-147.html) |
| Le Labo | THÉ NOIR 29 · EDP | 关键：佛手柑、无花果、月桂叶、雪松、香根草、麝香、红茶、干草、烟草 | [官方页面](https://www.lelabofragrances.com/th-noir-29-148.html?size=50+ml+%2F+1.7+fl+oz) |
| Le Labo | ANOTHER 13 · EDP | 关键：降龙涎香醚、茉莉、苔藓 | [官方页面](https://www.lelabofragrances.com/another-13-463.html?size=50ml) |
| Le Labo | ROSE 31 · EDP | 关键：千叶玫瑰、孜然、乳香、雪松、琥珀、愈创木、岩蔷薇、麝香 | [官方页面](https://www.lelabofragrances.com/rose-31-146.html) |
| Aesop 伊索 | Tacit · EDP | 前：柚子、罗勒、丁香；中：迷迭香、薄荷、茴香；后：雪松、香根草、琥珀；关键：柚子、香根草、罗勒 | [官方页面](https://www.aesop.com/fragrance/fresh/tacit-eau-de-parfum/FR12.html?dwvar_FR12_size=100+mL+%5E+3.3+fl+oz) |
| Aesop 伊索 | Hwyl · EDP | 前：百里香、榄香脂、粉红胡椒；中：柏树、麂皮、天竺葵；后：香根草、乳香、雪松；关键：柏树、乳香、香根草 | [官方页面](https://www.aesop.com/fragrance/woody/hwyl-eau-de-parfum/FR15.html) |
| Aesop 伊索 | Marrakech Intense · EDP | 前：佛手柑、橙花、茉莉；中：玫瑰、小豆蔻、广藿香；后：檀香、雪松、丁香；关键：丁香、檀香、小豆蔻 | [官方页面](https://www.aesop.com/fragrance/marrakech-intense-eau-de-parfum/FR39.html) |
| Aesop 伊索 | Eidesis · EDP | 前：苦橙叶、黑胡椒、乳香；中：孜然、雪松、乳香；后：檀香、雪松、香根草；关键：黑胡椒、乳香、檀香 | [官方页面](https://www.aesop.com/uk/p/fragrance/opulent/eidesis-eau-de-parfum/) |
| Dior 迪奥 | Sauvage Eau de Parfum · EDP | 前：佛手柑；中：花椒、薰衣草、八角；后：香草、降龙涎香醚；关键：佛手柑、香草、广藿香 | [官方页面](https://www.dior.com/en_us/beauty/products/sauvage-eau-de-parfum-E000000376.html) |
| Dior 迪奥 | Miss Dior Blooming Bouquet · EDT | 前：香豌豆、佛手柑；中：大马士革玫瑰、牡丹；后：白麝香；关键：佛手柑、玫瑰、牡丹、白麝香 | [官方页面](https://www.dior.com/en_int/beauty/products/miss-dior-blooming-bouquet-Y0996612.html) |
| Dior 迪奥 | J’adore Eau de Parfum · EDP | 关键：依兰、大马士革玫瑰、大花茉莉、沙巴茉莉 | [官方页面](https://www.dior.com/en_us/beauty/products/j%E2%80%99adore-eau-de-parfum-C099800245.html) |
| Dior 迪奥 | Gris Dior · EDP | 关键：柑橘、玫瑰、紫罗兰、橡木苔 | [官方页面](https://www.dior.com/en_us/beauty/products/gris-dior-Y0840550.html) |
| Hermès 爱马仕 | Un Jardin sur le Nil · EDT | 关键：青芒果、莲花、西克莫木 | [官方页面](https://www.hermes.com/us/en/product/un-jardin-sur-le-nil-eau-de-toilette-V26993/) |
| Hermès 爱马仕 | Terre d’Hermès · EDT | 关键：葡萄柚、雪松、燧石 | [官方页面](https://www.hermes.com/us/en/product/terre-d-hermes-eau-de-toilette-V107188V0/) |
| Hermès 爱马仕 | Twilly d’Hermès · EDP | 关键：生姜、晚香玉、檀香 | [官方页面](https://www.hermes.com/us/en/product/twilly-d-hermes-eau-de-parfum-V107263V0/) |
| Hermès 爱马仕 | Un Jardin à Cythère · EDT | 关键：禾草、橄榄木、鲜开心果 | [官方页面](https://www.hermes.com/us/en/product/un-jardin-a-cythere-eau-de-toilette-V109288V0/) |
| CHANEL 香奈儿 | COCO MADEMOISELLE · EDP | 关键：橙、茉莉、五月玫瑰、广藿香、香根草 | [官方页面](https://www.chanel.com/us/fragrance/p/116520/coco-mademoiselle-eau-de-parfum-spray/) |
| CHANEL 香奈儿 | CHANCE EAU TENDRE · EDT | 关键：葡萄柚、榅桲、茉莉、白麝香 | [官方页面](https://www.chanel.com/fr/parfums/p/126320/chance-eau-tendre-eau-de-toilette-vaporisateur/) |
| CHANEL 香奈儿 | N°5 · EDP | 前：柑橘；关键：柑橘、五月玫瑰、茉莉、醛香、波旁香草 | [官方页面](https://www.chanel.com/us/fragrance/p/125430/n5-eau-de-parfum-spray/) |
| CHANEL 香奈儿 | BLEU DE CHANEL · EDP | 关键：琥珀香调、麝香香调、雪松、檀香 | [官方页面](https://www.chanel.com/us/fragrance/p/107350/bleu-de-chanel-eau-de-parfum-spray/) |
| Givenchy 纪梵希 | L’Interdit · EDP | 前：佛手柑、鲜姜；中：橙花、沙巴茉莉、晚香玉；后：广藿香、香根草；关键：佛手柑、鲜姜、橙花、沙巴茉莉、晚香玉、广藿香、香根草 | [官方页面](https://www.givenchybeauty.com/int/en/p/l-interdit-P069321.html) |
| Givenchy 纪梵希 | Irresistible · EDP | 前：梨香调、黄葵；中：玫瑰、鸢尾；后：雪松、浅色木质香调；关键：梨香调、黄葵、玫瑰、鸢尾、雪松、浅色木质香调 | [官方页面](https://www.givenchybeauty.com/us/p/irresistible-F10100128.html) |
| Givenchy 纪梵希 | Gentleman Réserve Privée · EDP | 前：佛手柑、威士忌；中：栗子、鸢尾根、安息香；后：雪松、香根草、广藿香；关键：佛手柑、威士忌、栗子、鸢尾根、安息香、雪松、香根草、广藿香 | [官方页面](https://www.givenchybeauty.com/us/p/gentleman-reserve-privee-P011161.html) |
| Givenchy 纪梵希 | Ange ou Démon Le Secret · EDP | 前：蔓越莓；中：茶、茉莉；后：浅色木质香调；关键：蔓越莓、茶、茉莉、浅色木质香调、柠檬、绿茶香调 | [官方页面](https://www.givenchybeauty.com/ca/fr/p/ange-ou-demon-le-secret-F10100004.html) |
| Giorgio Armani 阿玛尼 | Sì Eau de Parfum Intense · EDP Intense | 前：黑加仑果蜜；中：大马士革玫瑰、达瓦纳；后：波旁香草、红茶；关键：黑加仑果蜜、大马士革玫瑰、达瓦纳、波旁香草、红茶 | [官方页面](https://www.armanibeauty.co.uk/perfume/womens-perfumes/si/si-eau-de-parfum-intense-refillable/ww-00745-arm.html) |
| Giorgio Armani 阿玛尼 | My Way · EDP | 前：佛手柑、橙花；中：晚香玉、茉莉；后：雪松、香草、白麝香；关键：佛手柑、橙花、晚香玉、茉莉、雪松、香草、白麝香 | [官方页面](https://www.armanibeauty.co.uk/perfume/womens-perfumes/my-way/my-way-eau-de-parfum---refillable/ww-00343-arm.html) |
| Giorgio Armani 阿玛尼 | Acqua di Gioia · EDP | 前：柠檬、薄荷；中：水茉莉香调；后：雪松、岩蔷薇脂、红糖香调；关键：柠檬、薄荷、水茉莉香调、雪松、岩蔷薇脂、红糖香调 | [官方页面](https://www.giorgioarmanibeauty-usa.com/acqua-di-gioia-eau-de-parfum-duo/3614274339154.html) |
| Giorgio Armani 阿玛尼 | Armani/Privé Thé Yulong · EDT | 关键：青柑橘、绿茶、红茶 | [官方页面](https://www.giorgioarmanibeauty-usa.com/fragrances/armani/prive/les-eaux/armani/prive-the-yulong/A2254.html) |
| Yves Saint Laurent 圣罗兰 | Libre · EDP | 关键：薰衣草、橙花、麝香香调、香草 | [官方页面](https://www.yslbeautyus.com/fragrance/womens-fragrances/libre/libre-eau-de-parfum/3614272648418.html?geo=false) |
| Yves Saint Laurent 圣罗兰 | Black Opium · EDP | 关键：咖啡、白花香调、香草 | [官方页面](https://www.yslbeautyus.com/fragrance/womens-fragrances/black-opium/black-opium-eau-de-parfum/252YSL.html) |
| Yves Saint Laurent 圣罗兰 | Mon Paris · EDP | 关键：红色浆果香调、曼陀罗花香调、白麝香、广藿香 | [官方页面](https://www.yslbeautyus.com/fragrance/womens-fragrances/mon-paris/mon-paris-eau-de-parfum/3614272048447.html) |
| Yves Saint Laurent 圣罗兰 | Y Eau de Parfum · EDP | 关键：鼠尾草、天竺葵、木质香调 | [官方页面](https://www.yslbeautyus.com/fragrance/featured/refillable-fragrance/y-eau-de-parfum/3614274057348.html) |
| Jo Malone London 祖玛珑 | Wood Sage & Sea Salt · Cologne | 前：黄葵籽；中：海盐香调；后：鼠尾草；关键：黄葵籽、海盐香调、鼠尾草 | [官方页面](https://www.jomalone.com/scents/woody/wood-sage-sea-salt) |
| Jo Malone London 祖玛珑 | English Pear & Freesia · Cologne | 前：威廉梨香调；中：小苍兰；后：广藿香；关键：威廉梨香调、小苍兰、广藿香、玫瑰 | [官方页面](https://www.jomalone.co.uk/product/25946/12553/colognes/english-pear-freesia-cologne) |
| Jo Malone London 祖玛珑 | Peony & Blush Suede · Cologne | 前：红苹果香调；中：牡丹香调；后：麂绒香调；关键：红苹果香调、牡丹香调、麂绒香调、茉莉、玫瑰 | [官方页面](https://www.jomalone.co.uk/product/25946/27028/colognes/peony-blush-suede-cologne) |
| Jo Malone London 祖玛珑 | Lime Basil & Mandarin · Cologne | 前：柑橘；中：罗勒；后：琥珀木香调；关键：柑橘、青柠、罗勒、白百里香、琥珀木香调 | [官方页面](https://www.jomalone.co.uk/product/25946/10101/colognes/lime-basil-mandarin-cologne?size=9ml) |

版本差异、三调披露边界、官方链接和核查日完整保存在 [catalog.json](data/catalog.json)。不同地区官网可能更新，现场购买时请核对英文名、浓度和包装。

特别案例：Thé Yulong 的英国页面提及 EDT/EDP 标签过渡，当前条目固定美国 EDT 页面；部分官网的比较表与单品文案不同，本库采用有对应浓度的明确单品说明。

## 第二步：香材的西方象征传统

主要采用 Agrippa《Three Books of Occult Philosophy》第一卷的 1651 英译数字转录，以及 Project Gutenberg 所载 Culpeper《The Complete Herbal》的 1850 后世编订本。这里的“核实”仅指在历史文本中找到该记载，不表示其好运或占星效果成立。

古代焚香不是现代皮肤香水；只整理对应，不提供历史药方、动物材料配方或焚烧操作。原典 cedar、sanders、citron 等名称不能自动对应到现代供应链的某个物种。

| 香材 | 核查到的历史记载 | 本产品的现代仪式解释 | 来源 / 状态 |
| --- | --- | --- | --- |
| 玫瑰 | Agrippa 将玫瑰列为金星焚香。 | 现代仪式设计：提醒自己温和表达、认真倾听；用于关系目标的象征标签。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44（1651 英译转录）](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 肉桂 | Agrippa 将肉桂列入水星芳香材料。 | 现代仪式设计：把温暖辛香当作主动开口、推进下一步的提醒。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 柠檬／枸橼果皮 | Agrippa 将 citron peel 列入水星焚香。 | 现代仪式设计：象征开始前理清要说的三件事；不自动套用于佛手柑。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 乳香 | Agrippa 将乳香对应太阳、狮子座。 | 现代仪式设计：作为上场前确认价值和表达立场的个人提示。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 没药 | Agrippa 的太阳、土星配方及白羊对应均含没药。 | 现代仪式设计：用作复盘、设边界与沉着开始的象征。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 雪松 | Agrippa 将 cedar 列为奉献给 Phoebus 的树。 | 现代仪式设计：象征站稳自己的立场，提示重要谈话前准备充分。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 23](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 檀香 | Agrippa 的 sanders 见金星、火星及处女座对应。 | 现代仪式设计：象征耐心打磨作品和有分寸地接近他人。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapters 28 and 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 薰衣草 | Culpeper 的 Lavender 条目将它归水星。 | 现代仪式设计：提醒自己先整理思路再表达；不将古代医药说法作为疗效。 | [Nicholas Culpeper, The Complete Herbal, Lavender（1850 版，Project Gutenberg 转录）](https://www.gutenberg.org/files/49513/49513-h/49513-h.htm) |
| 迷迭香 | Culpeper 归太阳、白羊；Agrippa 的第 24 章归月亮。 | 现代仪式设计：提示自己返回计划、执行一项明确行动；展示传统分歧。 | [Culpeper, The Complete Herbal, Rosemary（1850 版）；Agrippa, Book I, chapter 24](https://www.gutenberg.org/files/49513/49513-h/49513-h.htm) |
| 接骨木 | Culpeper 将 elder 与 dwarf elder 都归金星。 | 现代仪式设计：作为友善联结与相互照顾的象征；不据此声称驱邪或增运。 | [Culpeper, The Complete Herbal, The Elder Tree / The Dwarf-Elder（1850 版）](https://www.gutenberg.org/files/49513/49513-h/49513-h.htm) |
| 安息香 | Agrippa 将 benzoin 用于木星配方、摩羯座焚香。 | 现代仪式设计：用作长程目标中稳定投入、守住节奏的提示。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 肉豆蔻 | Agrippa 将 nutmeg 对应木星芳香材料。 | 现代仪式设计：象征保持开放，准备好尝试新的合作或学习机会。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 丁香（香辛料） | Agrippa 的丁香见木星芳香材料及太阳、水星配方。 | 现代仪式设计：把辛香当成开会前明确重点与主动交流的提示。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 岩蔷薇树脂／劳丹脂 | Agrippa 的 ladanum 见金星及太阳材料列表。 | 现代仪式设计：象征温暖而有边界的表达，用于重要关系或自我展示。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapters 28 and 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 藏红花 | Agrippa 将 saffron 列入金星芳香材料。 | 现代仪式设计：象征表达欣赏和体面地展现自己。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 茉莉 | 本轮未核实茉莉招财、预知或助恋爱的指定原典。 | 如产品使用温柔、自信或夜间氛围标签，应标明是现代香气叙事，而非古代传统结论。 | 指定说法未核实 |
| 佛手柑 | 本轮未核实佛手柑招财或成功的指定原典；不能直接借用 citron peel 的对应。 | 清新、明亮可用作嗅觉风格描述；幸运标签若采用，应明示为产品自己的仪式设计。 | 指定说法未核实 |

不同传统不是一套统一标准：迷迭香在 Agrippa 与 Culpeper 中存在不同对应；檀香也有多重对应。网页保留差异。此表只作为解释旁注，不额外添加所谓财运、桃花运或学业运功效分。

## 第三步：嗅觉、情绪、记忆与偏好

以下是围绕产品设计问题挑选的一手研究，不是完整系统综述。商业香水是复杂混合物，香调词也可能由其他材料重建；精油或单分子实验不能直接外推到某款成品。

### 1. 个人记忆赋予气味情绪意义

Rachel S. Herz, James Eliassen, Sophia Beland, Timothy Souza，2004。样本：5 名健康、右利手女性。

方法：个人重要记忆的气味与视觉线索、相应对照线索的行为测量及 fMRI 比较。

结果：个人重要气味引发更强的主观情绪反应，并伴随杏仁核与海马区域更强激活。

局限：样本极小且仅女性；研究记忆唤起，未测量考试、面试、恋爱或创业结果；不能证明任一香材具有固定情绪效果。

设计启示：记录用户的美好记忆和不愉快联想。已验证让本人感觉舒适的香水应高于通用香材标签。

来源：[Neuroimaging evidence for the emotional potency of odor-evoked memory](https://pubmed.ncbi.nlm.nih.gov/14670575/)；DOI：10.1016/j.neuropsychologia.2003.08.009。

### 2. 描述和期待会改变同一种气味的体验

Ivan E. de Araujo, Edmund T. Rolls, Maria Inés Velazco, Christian Margot, Isabelle Cayeux，2005。样本：12 名健康、右利手男性，23–35 岁。

方法：事件相关 fMRI；同一种异戊酸与奶酪香气混合刺激，交替标注为奶酪或体味，并设置洁净空气条件。

结果：同一气味被标注为体味时愉悦度更低；部分与奖赏及情绪相关的脑区反应也随标签改变。

局限：样本小且仅男性；特殊实验刺激不能代表商业香水；文字期待不等于现实任务成功。

设计启示：推荐文案使用可核验描述，并把仪式提示明确称为个人意图，避免用保证好运的说法塑造错误期待。

来源：[Cognitive Modulation of Olfactory Processing](https://www.oxcns.org/papers/381_DeAraujo%2BRolls%2B%2B%2B05.pdf)；DOI：10.1016/j.neuron.2005.04.021。

### 3. 柠檬气味的情绪实验与无效结果

Janice K. Kiecolt-Glaser 等，2008。样本：56 名健康成年男女。

方法：随机、交叉、三次实验室访问；分别接触柠檬精油、薰衣草精油与水；比较冷压应激前后，并操纵期待信息。

结果：柠檬条件下积极情绪更高；未可靠改善疼痛评分、心率、血压、唾液皮质醇及多项免疫和皮肤修复指标。

局限：精油、暴露剂量与实验时长特定；不能将结果外推到标有柠檬或佛手柑香调的香水，也不能推断治疗或成功率。

设计启示：柑橘可作为供用户试闻的清新风格候选；实际推荐仍由本人喜欢程度和场合决定。

来源：[Olfactory Influences on Mood and Autonomic, Endocrine, and Immune Function](https://pmc.ncbi.nlm.nih.gov/articles/PMC2278291/)；DOI：10.1016/j.psyneuen.2007.11.015。

### 4. 注意力与记忆结果并非越清醒越好

Mark Moss, Jenny Cook, Keith Wesnes, Paul Duckett，2003。样本：144 名志愿者，迷迭香、薰衣草及无香气三组各 48 人。

方法：随机组间实验；在有精油气味或无气味的小隔间完成计算机认知任务与心情量表；实验目的对参与者隐瞒。

结果：迷迭香组部分记忆指标较好，却有记忆反应变慢；薰衣草组工作记忆及部分反应速度较差。迷迭香组报告更高警觉性。

局限：单次实验、多项指标、气味难以完全盲法；主观警觉不代表所有注意任务改善；不能据此保证含迷迭香香水提高学习成绩。

设计启示：重要面试和学习场景优先使用曾试过且不分心的香气，提供个人试用记录，不设置香材自动提升智力分。

来源：[Aromas of rosemary and lavender essential oils differentially affect cognition and mood in healthy adults](https://pubmed.ncbi.nlm.nih.gov/12690999/)；DOI：10.1080/00207450390161903。

### 5. 个人偏好是推荐的重要输入

Artin Arshamian 等，2022。样本：9 个不同非西方文化群体的 225 人。

方法：对 10 种单分子气味进行愉悦度排序，比较文化、气味身份与个体差异。

结果：研究模型中个体差异、气味身份与文化分别解释约 54%、41%、6% 的排序差异；百分数因取整合计略超 100%。

局限：只有 10 种单分子刺激，不能代表所有复杂香水；个体差异项也包含测量噪声；研究无法区分先天因素与共同学习经历。

设计启示：让用户标记喜欢、不喜欢、熟悉和曾穿着愉快的香水；不要根据文化或星座推断她必然喜欢某种味道。

来源：[The perception of odor pleasantness is shared across cultures](https://ora.ox.ac.uk/objects/uuid%3A2f4cefa9-846d-4235-9c4b-160545ea0b49)；DOI：10.1016/j.cub.2022.02.062。

### 6. 相似的嗅觉基础仍容纳文化差异

Piotr Sorokowski, Michał Misiak, S. Craig Roberts 等，2024。样本：582 人；Hadza、Tsimane’、Yali、波兰及马来西亚五组。

方法：对 15 种气味样本作愉悦度评分，并比较不同生活环境与文化群体。

结果：发现跨文化相似性，也发现无法支持气味偏好完全普遍一致的差异；环境中的气味可接触性值得考虑。

局限：跨文化观察比较不能隔离全部因果因素；样本与刺激不同于 2022 年研究，并非其直接复现。

设计启示：推荐保持可更改与可反馈；熟悉度和个人经验优先于把某类香调固定称为人人舒适。

来源：[Is the perception of odour pleasantness shared across cultures and ecological conditions? Evidence from Amazonia, East Africa, New Guinea, Malaysia and Poland](https://pubmed.ncbi.nlm.nih.gov/38863390/)；DOI：10.1098/rsbl.2024.0120。

## 第四步：占星选香算法（2026-10-23 更新）

### 4.1 天文输入与计算

`core.js` 和 `astrology.js` 使用固定版本 Astronomy Engine 2.1.19。出生日期、当地时间、经纬度与出生时 UTC 时差决定热带黄道的地心星位。太阳使用 SunPosition，月亮使用 EclipticGeoMoon，其余行星使用 GeoVector → Ecliptic。上升是黄道与东侧地平线的交点，已用独立的坐标旋转/地平高度计算检验。

本次选香使用太阳、月亮、水星、金星、火星、木星、土星七曜。传统守护星采用：白羊/天蝎火星，金牛/天秤金星，双子/处女水星，巨蟹月亮，狮子太阳，射手/双鱼木星，摩羯/水瓶土星。传统尊贵状态采用入庙、擢升、失势、落陷四项；不声称实现完整古典尊贵表。

整宫制以整个上升星座为第一宫，按星座顺序分配其余宫位；不把第十宫宫头当作天文 MC。|出生纬度| ≥66° 时不计算上升、命主星或宫位。只填出生日期时使用当地中午的太阳，并检测当天换座；不猜测月亮、金星、上升或宫位。若当天太阳换座且未提供时间，则关闭本命占星权重。

参考：[Astronomy Engine v2.1.19](https://github.com/cosinekitty/astronomy/blob/v2.1.19/source/js/README.md)、[Dorotheus《占星诗》第一卷的守护与擢升记载](https://www.skyscript.co.uk/dorotheus1.pdf)。

### 4.2 从实际星盘建立行星侧重

本命基准权重：太阳 0.9、月亮 1.0、水星 0.65、金星 1.5、火星 0.5、木星 0.45、土星 0.4。入庙 ×1.15、擢升 ×1.08、失势 ×0.90、落陷 ×0.94。每个行星还向其落座的传统守护星分配 45% 权重，向该落座的星座香材分配 45% 权重。命主星另加 1.4。

本命主要相位为合相、六合、刑相、拱相、对冲；涉及日月时容许度 8°，其他 6°。相位只增加行星在本命主题中的显著程度：每条以 `0.06 × (1 − 偏差/容许度)` 增加权重，累计上限 0.3。它不把所有相位解释成吉相，也不把刑冲等同于坏事。

目标及场合选择相关行星与宫位：事业使用太阳/火星/木星及第 10、2 宫；学习成长使用水星/木星/土星及第 9、3 宫；关系使用金星/月亮及第 7、5 宫；约会第 5、7 宫，客户面谈第 7、10 宫，社交第 11、7 宫等。宫主星由个人上升与整宫盘计算，而不是把第七宫一律当作金星。每个相关宫主星增加 1.1 的主题权重；阶段目标与当天事件同时存在时，目标主题乘 0.45、当天主题乘 1。

宫位传统主题出处：[Lilly《Christian Astrology》1647，pp.50–56](https://www.skyscript.co.uk/lilly_houses.html)。整宫制是 Pronoia 的明确选择，不声称 Lilly 在这些例子中采用整宫制。将现代任务映射到这些主题及数值权重，是本产品的解释设计，并非历史文本提供的香水算法。

### 4.3 日期真正参与行运

阶段心愿使用目标日期；重要的一天使用当天日期。用户填写当地参考时间与该日 UTC 时差，缺省时间明确按中午 12:00。支持 1900–2100 年，不自动猜测历史或未来夏令时。

计算该时刻七曜星位；参考时刻月亮落座的守护星增加 0.9，该星座香材增加 0.4。出生时间完整时，将行运七曜与本命七曜比较主要相位，容许度 3°。命中的本命行星获得 `(0.15 + 0.35 × 目标相关程度) × (1 − 偏差/3)` 的侧重。

这里只代表所选时刻，不把单次取样说成整个阶段或全天的趋势。没有择吉、太阳返照、推运、完整入相/出相分析或事件成功预测。

### 4.4 行星、星座与香材

直接对应主要取自 [Agrippa《Three Books of Occult Philosophy》第一卷第 44 章](https://www.esotericarchives.com/agrippa/op1.htm)，金星的檀香补充自第 28 章。例：金星—玫瑰/紫罗兰/藏红花；水星—肉桂/柠檬皮；木星—肉豆蔻/安息香；太阳—乳香/麝香；土星—没药。完整对应在 `CORRESPONDENCES`。

同时保留独立的十二星座香材列表，例如狮子—乳香、处女—檀香、摩羯—安息香。没有现代香水匹配的历史材料留空，不用别的材料冒充。

古典文本中的芳香根、叶、花、木、果实与皮等大类可延伸到现代香调，但明确标注“香调类别延伸”。比如香根草归入芳香根、茶归入叶；它们不能被描述成作者逐字指定的对应。直接命中一种不同香调取 0.85，两种及以上上限 1；仅命中类别延伸取 0.5。重复词不加分。普通琥珀、Ambroxan 不冒充龙涎香；玫瑰木不冒充玫瑰，红没药不冒充没药。只匹配产品公开的香调名称，不据此推断植物原料实际含量。

将香水的七曜对应分布与星盘所需七曜权重作余弦相似度比较，再乘对应证据强度上限；避免“公开香调越多就必然得分越高”。占星项 = 85% 行星分布契合 + 15% 星座香材命中比例。未命中的香调不会编造占星理由。

### 4.5 与个人偏好及实际场合结合

24 个中英文感觉及自由填写关键词映射到专注、安定、自信、亲和、活力、灵感六个编辑维度；多选等权合并、同一种感觉去重。没有选项且无识别词时偏好为 0.6。喜欢标记额外增加 0.15，上限 1。目标与场合的气味风格匹配保留六维规则；这些是产品参数，不是实测心理功效。

| 模式 | 占星香调匹配 A | 目标 G | 场合 E | 偏好 P |
| --- | ---: | ---: | ---: | ---: |
| 本命香 | 0.65 | 0 | 0 | 0.35 |
| 阶段心愿 | 0.55 | 0.25 | 0 | 0.20 |
| 重要一天 | 0.50 | 0.10 | 0.25 | 0.15 |

`score = round(100 × (wA·A + wG·G + wE·E + wP·P))`。关闭占星或太阳换座未确定时，占星权重设为零，其余归一化。

先执行香水柜、排除香调和强度上限等硬约束，再按分数选最多三款，重复品牌扣 3 个选取排序点、重复香型扣 4 点。卡片上的原始匹配分不受多样性调整影响。叠喷只枚举两款，强度和不得超过 4，且需共同公开香调或相同香型；个人记录不能因都属于“自定义香气”就自动配对。保留有品牌依据的 Jo Malone 配对，但同样服从香水柜和筛选限制。

### 4.6 解释与验证

每款推荐显示实际参与的本命星位、守护星、宫主星或行运相位，以及匹配到的公开香调。详情展示原文来源与计算范围。星盘及日期确实影响排序；“按占星体系推荐”和“香水能因果性改变运势”是不同命题，后者不由这些计算证明。

36 项测试覆盖星位、上升的独立几何检查、整宫宫位、相位跨 0°、日期与时差、星盘/时间改变时的推荐差异、未知出生时间降级、材料误匹配、24 种感觉、多选/自填、香水柜硬约束和两瓶叠喷上限。演示出生资料不是用户资料。

## 上线后的验证路线

1. 产品可用性：是否理解三层输入、能否找到已有香水、是否看懂来源和“不保证好运”的边界。
2. 气味盲试：记录喜欢程度、舒适度、是否分心、场合是否合适；先不展示星盘与功效式标签，以减少期待偏差。
3. 个性化对照：比较纯个人偏好、场合规则、增加象征叙事后的满意度与复用率；逐步校准，而非把未验证权重称为智能科学模型。
4. 双香实测：记录具体产品版本、用量、试香纸/衣物/皮肤、时间与结果，保留不喜欢或冲突的组合。
5. 不以 offer、融资、考试或恋爱结果证明香水的因果作用；这些受大量其他因素影响。

## 已知限制与未完成范围

- 当前为 200 款、16 品牌代表资料，不包含各品牌全部系列或实时在售状态。
- 心理学研究为问题导向选读，不是系统综述或香水产品功效评价。
- 历史对应只核实记载，未核实的茉莉/佛手柑说法明确保留空来源。
- 没有价格/预算、天气、香水实际扩散度测量、用户账号、跨设备云同步或自动日程提醒。
- 提供整宫制与主要相位及参考时刻行运；不提供完整专业占星咨询、择吉或成功概率。历史时区依赖用户填写，不能通过生日猜月亮与上升。
- 叠喷除注明品牌建议外没有成品实测记录；始终最多两款。
- 用户收藏保存在本浏览器；出生资料不默认持久化。个人导出备份不应提交公开仓库。

## 源码与数据的可复核性

资料源链接逐条保存在 [catalog.json](data/catalog.json) 和 [evidence.json](data/evidence.json)。完整计算规则在 [core.js](core.js) 与 [astrology.js](astrology.js)，可运行测试位于 `tests/`。当前人工与自动验证记录见 [QA.md](QA.md)。

## Pronoia 双语实现补充

显示层可切换中文和英文，算法使用相同原始数据与同一组权重，切换语言不重新定义香水画像。英文翻译按稳定 ID 放在 data/en.json；香调别名同时参与搜索和排除。自由输入关键词已补充 business、growth、relationship、deep work、creative 等英文类别。无法识别时继续使用下拉选项。个人输入不通过远端翻译服务，保持原文。


## 2026-10-23 扩展图鉴

基础资料现为 16 品牌、200 款独立香水版本。新增 Etat Libre d’Orange、BDK、Maison Crivelli、Essential Parfums、Amouage、Parfums de Marly 共 160 款。逐条前中后调或关键材料、浓度和官网来源见 data/catalog.json；真实图片出处见 data/image-credits.json。旧版本中关于 40 款样本的叙述仅代表初版研究范围。研究资料保留在源码中，网页不显示“灵感与依据”栏目。
