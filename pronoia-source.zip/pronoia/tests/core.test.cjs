const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const C=require('../core.js');
const A=require('../vendor/astronomy.browser.min.js');
const catalog=JSON.parse(fs.readFileSync(path.join(__dirname,'../data/catalog.json'),'utf8'));
const evidence=JSON.parse(fs.readFileSync(path.join(__dirname,'../data/evidence.json'),'utf8'));
const chart=C.birthChart({date:'1998-05-16',offset:8},A);
const base={level:3,chart,useAstro:true,goal:'growth',event:'interview',likes:['focus','calm'],maxIntensity:3,owned:[],loved:[],allowLayer:true};
const ctx=x=>({...base,...x});
test('gender direction changes ranking with matched, unisex and unknown brand positioning',()=>{
 const choices=['male','female','unisex'];
 const samples=choices.map(audience=>({id:audience,brand:audience,family:audience,intensity:1,tags:['calm'],notes:{key:['玫瑰']},audience,audienceSource:'https://www.chanel.com/us/fragrance/'}));
 for(const gender of choices){const r=C.rank(samples,ctx({gender,level:1}));assert.equal(r.ranked[0].perfume.id,gender);assert.ok(r.ranked.every(x=>Math.abs(Object.values(x.weights).reduce((s,w)=>s+w,0)-1)<1e-12));}
 assert.equal(C.genderAffinity({notes:{key:['玫瑰','雪松']}},'male'),.5);
 assert.equal(C.genderAffinity({audience:'female'},'female'),.5);
 assert.equal(C.genderAffinity({audience:'unknown',audienceSource:'https://example.com'},'unisex'),.5);
});
test('gender direction preserves astrology and wardrobe constraints',()=>{
 const c=C.birthChart({date:'1998-05-16',time:'10:30',offset:8,lat:31.23,lon:121.47},A);
 const m=C.rank(catalog,ctx({chart:c,gender:'male'})),f=C.rank(catalog,ctx({chart:c,gender:'female'}));
 assert.deepEqual(m.analysis,f.analysis);assert.equal(m.ranked[0].parts.astro,f.ranked.find(x=>x.perfume.id===m.ranked[0].perfume.id).parts.astro);
 const owned=catalog.find(p=>p.audience==='female'&&p.intensity<=2),r=C.rank(catalog,ctx({gender:'male',ownedOnly:true,owned:[owned.id]}));
 assert.deepEqual(r.selected.map(x=>x.perfume.id),[owned.id]);assert.equal(C.layering(r.ranked,ctx({gender:'male'})),null);
});
test('catalogue positioning has explicit sources and unknown is distinct from unisex',()=>{
 assert.equal(catalog.filter(p=>p.audience!=='unknown').length,139);
 assert.equal(catalog.filter(p=>p.audience==='unknown').length,61);
 assert.ok(catalog.every(p=>p.audience==='unknown'||Object.hasOwn(C.GENDERS,p.audience)&&/^https:\/\//.test(p.audienceSource)&&p.audienceBasis));
 assert.equal(catalog.find(p=>p.id==='dior-gris-dior-edp').audience,'unisex');
});
test('24 bilingual feelings produce finite normalized preferences without changing catalogue tags',()=>{
 assert.equal(Object.keys(C.FEELINGS).length,24);assert.equal(Object.keys(C.TAGS).length,6);
 for(const [id,f] of Object.entries(C.FEELINGS)){
  assert.ok(f.zh&&f.en);const v=C.preferenceVector([id]);
  assert.equal(v.length,6);assert.ok(v.every(x=>Number.isFinite(x)&&x>=0&&x<=1));
  assert.ok(Math.abs(v.reduce((a,b)=>a+b,0)-1)<1e-12);
  const r=C.rank(catalog,ctx({likes:[id]}));assert.equal(r.selected.length,3);assert.ok(r.ranked.every(x=>x.score>=0&&x.score<=100));
 }
});
test('multiple feelings combine equally and duplicate text does not double count a choice',()=>{
 const a=C.preferenceVector(['romantic']),b=C.preferenceVector(['grounded']),mixed=C.preferenceVector(['romantic','grounded']);
 mixed.forEach((x,i)=>assert.ok(Math.abs(x-(a[i]+b[i])/2)<1e-12));
 assert.deepEqual(C.preferenceVector(['relaxed'],'放松、松弛、relaxed'),C.preferenceVector(['relaxed']));
 assert.deepEqual(C.preferenceVector(['focus','calm']),[.5,.5,0,0,0,0]);
});
test('custom feelings understand Chinese and English, including the input example',()=>{
 assert.deepEqual(C.parseFeelings('松弛一点，温柔但有力量'),['confidence','relaxed','gentle']);
 assert.deepEqual(C.parseFeelings('Relaxed, gentle but confident'),['confidence','relaxed','gentle']);
 assert.deepEqual(C.parseFeelings('不要性感，但想优雅'),['elegant']);
 assert.deepEqual(C.parseFeelings('not sensual, but elegant'),['elegant']);
 assert.deepEqual(C.parseFeelings('warmth and fresh'),['fresh','warm']);
 assert.deepEqual(C.parseFeelings('calamari freshness'),[]);
});
test('custom feelings affect actual ranking and unrecognised text keeps a neutral fallback',()=>{
 const data=[{id:'calm',brand:'A',family:'A',intensity:1,tags:['calm'],notes:{}},{id:'energy',brand:'B',family:'B',intensity:1,tags:['energy'],notes:{}}];
 const personal=ctx({level:1,useAstro:false,likes:[]});
 assert.equal(C.rank(data,{...personal,feelingText:'安定'}).ranked[0].perfume.id,'calm');
 assert.equal(C.rank(data,{...personal,feelingText:'energetic'}).ranked[0].perfume.id,'energy');
 assert.equal(C.preferenceVector(['unknown'],'未识别的词'),null);
 assert.equal(C.scorePerfume(data[0],{...personal,feelingText:'未识别的词'}).parts.preference,.6);
 assert.equal(C.preferenceVector(['__proto__']),null);
});
test('200 distinct versions, 16 brands, official sources and disclosed notes',()=>{
 assert.equal(catalog.length,200);assert.equal(new Set(catalog.map(p=>p.id)).size,200);assert.equal(new Set(catalog.map(p=>p.brand)).size,16);
 const domains=['artisanparfumeur.com','lelabofragrances.com','aesop.com','dior.com','hermes.com','chanel.com','givenchybeauty.com','giorgioarmanibeauty-usa.com','armanibeauty-usa.com','armanibeauty.co.uk','yslbeautyus.com','yslbeauty.co.uk','jomalone.com','jomalone.co.uk','etatlibredorange.com','bdkparfums.com','maisoncrivelli.us','maisoncrivelli.com','essentialparfums.com','amouage.com','parfums-de-marly.com'];
 for(const p of catalog){assert.ok(p.concentration&&p.noteDisclosure&&p.evidenceNote);assert.ok(C.allNotes(p).length>0);assert.ok(domains.some(d=>(new URL(p.sourceUrl).hostname===d||new URL(p.sourceUrl).hostname.endsWith('.'+d))),p.sourceUrl);assert.ok([1,2,3].includes(p.intensity));assert.ok(p.tags.every(t=>C.TAGS[t]));}
});
test('evidence corpus preserves unverified claims as unverified',()=>{assert.equal(evidence.studies.length,6);assert.equal(evidence.traditions.length,17);assert.equal(evidence.traditions.filter(t=>t.sourceUrl).length,15);});
test('date-only chart computes sun, not an invented moon or ascendant',()=>{assert.equal(chart.sun.name,'金牛');assert.equal(chart.moon,null);assert.equal(chart.asc,null);assert.equal(chart.placements.length,0);});
test('UTC offset changes moment; fractional offsets are preserved',()=>{const a=C.birthChart({date:'2000-01-01',time:'12:00',offset:5.5,lat:28,lon:77},A);assert.equal(a.utc,'2000-01-01T06:30:00.000Z');assert.equal(a.placements.length,10);assert.equal(a.placements[0].bodyName,'太阳');});
test('leap days, impossible dates, future dates and missing inputs',()=>{assert.doesNotThrow(()=>C.birthChart({date:'2000-02-29',offset:8},A));for(const date of ['2001-02-29','2023-13-01','2023-04-31','1899-01-01','2999-01-01',''])assert.throws(()=>C.birthChart({date,offset:8},A));assert.throws(()=>C.birthChart({date:'2000-01-01',offset:'',time:'12:00',lat:31,lon:121},A));assert.throws(()=>C.birthChart({date:'2000-01-01',offset:8,time:'25:00',lat:31,lon:121},A));assert.throws(()=>C.birthChart({date:'2000-01-01',offset:8,time:'12:00',lat:'',lon:121},A));});
test('solar boundary day disables symbolic score until exact time is provided',()=>{const cusp=C.birthChart({date:'2024-03-20',offset:0},A);assert.equal(cusp.uncertain,true);const row=C.scorePerfume(catalog[0],ctx({chart:cusp}));assert.equal(row.weights.astro,0);assert.ok(Math.abs(Object.values(row.weights).reduce((a,b)=>a+b)-1)<1e-10);});
test('ascendant lies on the eastern horizon using independent engine rotation',()=>{
 for(const [date,lat,lon,offset] of [['1998-05-16',31.23,121.47,8],['2000-01-01',40.71,-74,-5],['1985-08-04',-33.86,151.2,10]]){
  const c=C.birthChart({date,time:'10:30',offset,lat,lon},A),d=new Date(c.utc),r=c.asc.longitude*Math.PI/180;
  const eq=A.EquatorFromVector(A.RotateVector(A.Rotation_ECT_EQD(d),new A.Vector(Math.cos(r),Math.sin(r),0,d)));
  const horizon=A.Horizon(d,new A.Observer(lat,lon,0),eq.ra,eq.dec);
  assert.ok(Math.abs(horizon.altitude)<.00001,String(horizon.altitude));assert.ok(horizon.azimuth>0&&horizon.azimuth<180,String(horizon.azimuth));
 }
});
test('polar location does not fabricate ascendant',()=>{const c=C.birthChart({date:'2000-01-01',time:'12:00',offset:0,lat:70,lon:20},A);assert.equal(c.asc,null);assert.ok(c.moon);});
test('all levels give at most 3 unique results with bounded rule scores',()=>{for(const level of [1,2,3]){const r=C.rank(catalog,ctx({level}));assert.equal(r.selected.length,3);assert.equal(new Set(r.selected.map(r=>r.perfume.id)).size,3);r.ranked.forEach(x=>assert.ok(x.score>=0&&x.score<=100));}});
test('empty wardrobe produces zero recommendations and no layer',()=>{const context=ctx({ownedOnly:true}),r=C.rank(catalog,context);assert.equal(r.selected.length,0);assert.equal(C.layering(r.ranked,context),null);});
test('one owned fragrance cannot be padded into 3 or layered with unowned ones',()=>{const context=ctx({ownedOnly:true,owned:[catalog[0].id]}),r=C.rank(catalog,context);assert.equal(r.selected.length,1);assert.equal(r.selected[0].perfume.id,catalog[0].id);assert.equal(C.layering(r.ranked,context),null);});
test('exclusions and event intensity limits are hard constraints',()=>{const r=C.rank(catalog,ctx({exclude:'玫瑰，香草',event:'client',maxIntensity:3}));assert.ok(r.ranked.every(r=>r.perfume.intensity<=2));assert.ok(r.ranked.every(r=>!C.allNotes(r.perfume).some(n=>/玫瑰|香草/.test(n))));assert.ok(C.rank(catalog,ctx({maxIntensity:1})).ranked.every(r=>r.perfume.intensity===1));});
test('turning astrology off renormalizes remaining weights',()=>{for(const level of [1,2,3]){const a=C.scorePerfume(catalog[0],ctx({level,useAstro:false}));assert.equal(a.weights.astro,0);assert.ok(Math.abs(Object.values(a.weights).reduce((a,b)=>a+b)-1)<1e-10);}});
test('all chart/goal/event permutations preserve two-bottle limit and eligibility',()=>{for(const goal of Object.keys(C.GOALS))for(const event of Object.keys(C.EVENTS)){const context=ctx({goal,event}),r=C.rank(catalog,context),pair=C.layering(r.ranked,context);if(pair){assert.equal(pair.items.length,2);assert.notEqual(pair.items[0].id,pair.items[1].id);assert.ok(pair.items.every(p=>r.ranked.some(x=>x.perfume.id===p.id)));assert.ok(pair.items.reduce((s,p)=>s+p.intensity,0)<=4);}}});
test('official pairing remains constrained to owned/filter pool',()=>{const owned=['jo-malone-wood-sage-sea-salt','jo-malone-lime-basil-mandarin'],context=ctx({ownedOnly:true,owned}),r=C.rank(catalog,context);const pair=C.layering(r.ranked,context);assert.equal(pair.official,true);assert.equal(pair.items.length,2);assert.equal(C.layering(r.ranked,{...context,allowLayer:false}),null);});
test('unrelated custom perfumes do not match only because both are custom',()=>{const data=[{id:'custom-a',name:'a',family:'自定义香气',intensity:1,notes:{key:['梨']},tags:['energy']},{id:'custom-b',name:'b',family:'自定义香气',intensity:1,notes:{key:['皮革']},tags:['confidence']}];assert.equal(C.layering(C.rank(data,base).ranked,base),null);});
test('literal fig does not accidentally match generic flower characters',()=>{const p={notes:{key:['无花果']},tags:[]};assert.deepEqual(C.profile(p),[.25,.25,.25,.25,.25,.25]);});
test('free text interpretation is deterministic and falls back for unknown words',()=>{assert.equal(C.classifyText('我要申请博士','custom','goal'),'growth');assert.equal(C.classifyText('明天客户面谈','date','event'),'client');assert.equal(C.classifyText('外星人来访','custom','event'),'custom');});
const english=JSON.parse(fs.readFileSync(path.join(__dirname,'../data/en.json'),'utf8'));
const noteAliases=Object.fromEntries(catalog.map(p=>[p.id,Object.values(english.catalog[p.id].notes).flat().join(' ')]));
test('English coverage retains all catalogue notes and all evidence records',()=>{
 assert.deepEqual(Object.keys(english.catalog).sort(),catalog.map(p=>p.id).sort());
 for(const p of catalog){for(const k of Object.keys(p.notes))assert.equal(english.catalog[p.id].notes[k].length,p.notes[k].length,p.id+' '+k);assert.doesNotMatch(JSON.stringify(english.catalog[p.id]),/[\u3400-\u9fff]/);}
 for(const type of ['studies','traditions']){assert.deepEqual(Object.keys(english[type]).sort(),evidence[type].map(p=>p.id).sort());for(const p of Object.values(english[type]))assert.doesNotMatch(JSON.stringify(p),/[\u3400-\u9fff]/);}
});
test('English note exclusions are hard constraints and do not depend on UI locale',()=>{
 const excluded=C.rank(catalog,ctx({exclude:'bergamot',noteAliases}));assert.ok(excluded.poolCount<catalog.length);assert.ok(excluded.ranked.every(r=>!noteAliases[r.perfume.id].toLowerCase().includes('bergamot')));
 const zh=C.rank(catalog,ctx({exclude:'佛手柑',noteAliases}));assert.deepEqual(excluded.ranked.map(x=>x.perfume.id),zh.ranked.map(x=>x.perfume.id));
});
test('English goals and occasions match documented categories without date substring collisions',()=>{
 for(const [text,key] of [['Start a business','startup'],['personal growth','growth'],['relationship','relationship'],['Build a learning habit','growth'],['reset my routine','reset']])assert.equal(C.classifyText(text,'custom','goal'),key);
 for(const [text,key] of [['client meeting','client'],['deep work','study'],['creative exploration','creative'],['a date','date'],['Update the proposal','study']])assert.equal(C.classifyText(text,'study','event'),key);
});
