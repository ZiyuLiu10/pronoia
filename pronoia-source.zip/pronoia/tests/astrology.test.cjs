const test=require('node:test');
const assert=require('node:assert/strict');
const C=require('../core.js');
const A=require('../vendor/astronomy.browser.min.js');
const data=require('../data/catalog.json');
const full=(date='1998-05-16',time='10:30',lat=31.23,lon=121.47)=>C.birthChart({date,time,offset:8,lat,lon},A);
const ctx=chart=>({level:1,chart,useAstro:true,likes:['focus','calm'],maxIntensity:2});
const one=(notes,planet)=>C.ASTRO.match({notes:{key:notes}},{signals:[{planet,kind:'natal',weight:1}]}).score;

test('complete birth data produces seven classical planets, actual Venus and whole-sign houses',()=>{
 const c=full();assert.equal(Object.keys(c.planets).length,7);assert.ok(c.aspects.length>0);
 assert.equal(c.planets.Venus.index,0);assert.equal(c.asc.name,'狮子');assert.equal(c.chartRuler,'Sun');
 assert.equal(c.planets.Sun.house,10);assert.equal(c.planets.Venus.house,9);assert.equal(c.houseSystem,'whole-sign');
 assert.equal(c.planets.Uranus,undefined);
});
test('unknown birth time and polar latitude never invent natal Venus, angles or houses',()=>{
 const partial=C.birthChart({date:'1998-05-16',offset:8},A);assert.deepEqual(Object.keys(partial.planets),['Sun']);assert.deepEqual(partial.aspects,[]);assert.equal(partial.chartRuler,null);assert.equal(partial.houseSystem,null);
 const polar=full('1998-05-16','10:30',70,20);assert.equal(polar.chartRuler,null);assert.ok(Object.values(polar.planets).every(p=>p.house===null));
 const cusp=C.birthChart({date:'2024-03-20',offset:0},A);assert.equal(C.ASTRO.buildTarget(cusp).available,false);
});
test('same Sun sign with different actual Venus placements changes perfume ranking',()=>{
 const a=full(),b=full('2000-05-16');assert.equal(a.sun.index,b.sun.index);assert.notEqual(a.planets.Venus.index,b.planets.Venus.index);
 const ra=C.rank(data,ctx(a)),rb=C.rank(data,ctx(b));assert.notDeepEqual(ra.selected.map(r=>r.perfume.id),rb.selected.map(r=>r.perfume.id));
 assert.ok(ra.ranked.some(x=>Math.abs(x.parts.astro-rb.ranked.find(y=>y.perfume.id===x.perfume.id).parts.astro)>.05));
});
test('birth time changes ascendant, chart ruler and the actual scent scores',()=>{
 const a=full(),b=full('1998-05-16','22:30');assert.notEqual(a.chartRuler,b.chartRuler);
 assert.notEqual(C.scorePerfume(data[0],ctx(a)).parts.astro,C.scorePerfume(data[0],ctx(b)).parts.astro);
});
test('future reference date uses its own timezone and accepts noon fallback',()=>{
 const a=C.skyAt({date:'2027-01-15',time:'12:00',offset:5.5},A);assert.equal(a.utc,'2027-01-15T06:30:00.000Z');assert.equal(Object.keys(a.planets).length,7);
 const b=C.skyAt({date:'2027-01-15',time:'',offset:5.5},A);assert.equal(b.utc,a.utc);assert.equal(b.assumedNoon,true);
 for(const input of [{date:'2027-02-29',time:'12:00',offset:0},{date:'2027-01-15',time:'24:00',offset:0},{date:'2027-01-15',time:'12:00',offset:''},{date:'2027-01-15',time:'12:00',offset:15}])assert.throws(()=>C.skyAt(input,A));
});
test('major aspects handle zodiac wraparound and enforce orb limits',()=>{
 assert.equal(C.ASTRO.aspect(359,1,3).angle,0);assert.equal(C.ASTRO.aspect(359,1,3).orb,2);
 assert.equal(C.ASTRO.aspect(359,179,3).angle,180);assert.equal(C.ASTRO.aspect(359,119,3).angle,120);
 assert.equal(C.ASTRO.aspect(10,54,3),null);
});
test('changing the occasion date changes transits and scores with the same natal chart',()=>{
 const c=full(),base={...ctx(c),level:3,goal:'growth',event:'client'},a=C.skyAt({date:'2026-10-23',time:'12:00',offset:8},A),b=C.skyAt({date:'2026-10-30',time:'12:00',offset:8},A);
 const ta=C.ASTRO.buildTarget(c,{...base,goalKey:'growth',eventKey:'client',sky:a}),tb=C.ASTRO.buildTarget(c,{...base,goalKey:'growth',eventKey:'client',sky:b});
 assert.ok(ta.transits.length>0);assert.notDeepEqual(ta.transits,tb.transits);
 const ra=C.rank(data,{...base,sky:a}),rb=C.rank(data,{...base,sky:b});assert.ok(ra.ranked.some(x=>Math.abs(x.parts.astro-rb.ranked.find(y=>y.perfume.id===x.perfume.id).parts.astro)>.02));
 assert.ok(ra.ranked.every(x=>x.score>=0&&x.score<=100));
});
test('career and relationship use different houses and their actual sign rulers',()=>{
 const c=full(),career=C.ASTRO.buildTarget(c,{level:2,goalKey:'startup'}),date=C.ASTRO.buildTarget(c,{level:3,goalKey:'custom',eventKey:'date'});
 assert.ok(career.signals.some(s=>s.kind==='house'&&s.house===10&&s.planet==='Venus'));
 assert.ok(date.signals.some(s=>s.kind==='house'&&s.house===7&&s.planet==='Saturn'));
 assert.notDeepEqual(career.signals,date.signals);
});
test('traditional notes match without confusing amber, ambrox, rosewood or unknown materials',()=>{
 assert.ok(one(['玫瑰'],'Venus')>0);assert.ok(one(['Cinnamon'],'Mercury')>0);assert.ok(one(['安息香'],'Jupiter')>0);
 assert.equal(one(['Amber'],'Sun'),0);assert.equal(one(['Ambroxan'],'Sun'),0);assert.equal(one(['降龙涎香醚'],'Sun'),0);
 assert.equal(one(['Rosewood'],'Venus'),0);assert.equal(one(['New unknown molecule'],'Venus'),0);
 assert.equal(one(['Violet leaf'],'Venus'),0);
 assert.equal(one(['红没药'],'Sun'),0);assert.equal(one(['乳香黄连木树脂'],'Moon'),0);
 assert.ok(one(['鸢尾根'],'Saturn')>0);assert.equal(one(['鸢尾根'],'Saturn'),.5);
});
test('matched notes are real published notes and duplicates do not inflate astrology score',()=>{
 const c=full(),r=C.rank(data,ctx(c));for(const row of r.ranked){const notes=C.allNotes(row.perfume);assert.ok(row.astrology.matches.every(m=>m.notes.every(n=>notes.includes(n))));}
 assert.equal(one(['玫瑰','玫瑰'],'Venus'),one(['玫瑰'],'Venus'));
 assert.ok(one(['玫瑰'],'Venus')>one(['玫瑰','乳香','肉桂','鸢尾根','檀香','安息香'],'Venus'));
});
test('astrology switch removes planetary and date influence from final scores',()=>{
 const a=full(),b=full('2000-05-16'),left=C.rank(data,{...ctx(a),useAstro:false}),right=C.rank(data,{...ctx(b),useAstro:false});
 assert.deepEqual(left.ranked.map(r=>[r.perfume.id,r.score]),right.ranked.map(r=>[r.perfume.id,r.score]));
});

function interpretationChart(){
 const c=full();c.asc={index:0};c.chartRuler='Mars';c.aspects=[];
 for(const [body,longitude] of Object.entries({Sun:20,Moon:140,Mercury:180,Venus:40,Mars:270,Jupiter:340,Saturn:200})){const index=Math.floor(longitude/30);c.planets[body]={body,longitude,index,degree:longitude%30,retrograde:false,house:index+1,dignity:C.ASTRO.dignity(body,index)};}
 return c;
}
test('solar condition boundaries distinguish cazimi, combustion and beams without overlap',()=>{
 for(const [separation,expected] of [[.2,'cazimi'],[1,'combust'],[8.5,'combust'],[9,'beams'],[17,'beams'],[18,null]]){
  const c=interpretationChart();c.planets.Mercury.longitude=c.planets.Sun.longitude+separation;
  const factors=C.ASTRO.condition('Mercury',c).factors.filter(f=>['cazimi','combust','beams'].includes(f.kind));
  assert.deepEqual(factors.map(f=>f.kind),expected?[expected]:[]);
 }
 assert.ok(!C.ASTRO.condition('Sun',interpretationChart()).factors.some(f=>['cazimi','combust','beams'].includes(f.kind)));
});
test('strained communication can draw on its actual stronger natal sign ruler',()=>{
 const c=interpretationChart();c.planets.Mercury.retrograde=true;c.aspects=[{a:'Mercury',b:'Mars',...C.ASTRO.aspect(180,270)}];
 const a=C.ASTRO.interpret(c,{level:3,goalKey:'custom',eventKey:'client'}),n=a.needs.find(n=>n.body==='Mercury');
 assert.equal(n.mode,'support');assert.equal(n.resource.planet,'Venus');assert.equal(n.resource.link,'dispositor');
 assert.ok(n.condition.factors.some(f=>f.kind==='retrograde'));assert.ok(n.condition.factors.some(f=>f.effect==='challenge'));
 assert.ok(a.conditions.Venus.strength>a.conditions.Mercury.strength);
});
test('hard and flowing transits lead to different needs, not the same amplification',()=>{
 const c=interpretationChart(),base={a:'Saturn',b:'Mercury',strength:1,orb:0},context={level:3,goalKey:'custom',eventKey:'client'};
 const hard=C.ASTRO.interpret(c,context,[{...base,angle:90}]).needs.find(n=>n.body==='Mercury');
 const soft=C.ASTRO.interpret(c,context,[{...base,angle:120}]).needs.find(n=>n.body==='Mercury');
 assert.ok(hard.priority>soft.priority);assert.ok(hard.pressure>soft.pressure);assert.equal(hard.mode,'support');assert.equal(soft.mode,'express');
 assert.equal(C.ASTRO.aspectEffect({angle:0},'Sun'),'activation');assert.equal(C.ASTRO.aspectEffect({angle:0},'Jupiter'),'flow');assert.equal(C.ASTRO.aspectEffect({angle:0},'Mars'),'challenge');
});
test('need interpretation affects scores and every resource has a natal link',()=>{
 const c=interpretationChart();c.planets.Mercury.retrograde=true;c.aspects=[{a:'Mercury',b:'Mars',...C.ASTRO.aspect(180,270)}];
 const target=C.ASTRO.buildTarget(c,{level:3,goalKey:'custom',eventKey:'client'}),r=C.ASTRO.match({notes:{key:['玫瑰']}},target);
 assert.ok(r.matches.some(m=>m.kind==='support'&&m.need.body==='Mercury'&&m.planet==='Venus'));assert.ok(r.supportScore>0);
 assert.equal(r.profileWeights.support,.75);
 const base=C.ASTRO.match({notes:{key:['玫瑰']}},{...target,signals:target.signals.filter(s=>s.kind!=='support')});assert.notEqual(r.score,base.score);
 for(const n of target.analysis.needs){assert.ok(n.resource.planet===n.body||n.resource.planet===C.ASTRO.RULERS[c.planets[n.body].index]||n.resource.aspect);}
});
test('partial charts do not manufacture lucky needs and custom goals do not invent a house',()=>{
 const partial=C.birthChart({date:'1998-05-16',offset:8},A),a=C.ASTRO.buildTarget(partial,{level:3,eventKey:'client'}).analysis;
 assert.equal(a.complete,false);assert.deepEqual(a.needs,[]);assert.equal(a.temperament,null);
 const c=full(),unknown=C.ASTRO.interpret(c,{level:2,goalKey:'custom'});assert.deepEqual(unknown.needs,[]);
 const explicit=C.ASTRO.interpret(c,{level:2,goalKey:'custom',intention:'confidence'});assert.equal(explicit.needs[0].body,'Sun');assert.ok(explicit.needs.every(n=>n.contexts.every(c=>c.kind!=='house')));
 assert.equal(C.rank(data,{...ctx(c),useAstro:false}).analysis,null);
});
test('element distribution describes natal style but does not prescribe a missing element',()=>{
 const c=interpretationChart(),a=C.ASTRO.interpret(c,{level:3,goalKey:'custom',eventKey:'client'});
 assert.ok(Math.abs(a.temperament.elements.reduce((s,e)=>s+e.share,0)-1)<1e-12);
 const b=C.ASTRO.interpret(c,{level:3,goalKey:'custom',eventKey:'study'});
 assert.deepEqual(a.temperament,b.temperament);assert.notDeepEqual(a.needs,b.needs);
 assert.ok(a.needs.every(n=>n.contexts.every(x=>x.kind!=='missing-element')));
});
