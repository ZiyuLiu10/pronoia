/* Public catalogue lookup. No profile or personal wardrobe leaves this browser. */
'use strict';
window.PronoaOnlineVersion='1.0';
window.PronoiaOnline=(()=>{
 const base=()=>String(window.PRONOIA_API||'').replace(/\/$/,'');
 const txt=(v,n=180)=>typeof v==='string'?v.slice(0,n):'';
 function clean(p){
  if(!p||!/^online-[a-f0-9]{24}$/.test(p.id)||!p.name||!p.brand||!/^https:\/\//.test(p.sourceUrl||''))return null;
  const notes=Object.fromEntries(['top','heart','base','key'].map(k=>[k,(Array.isArray(p.notes?.[k])?p.notes[k]:[]).map(x=>txt(x,85)).filter(Boolean).slice(0,12)]));
  const r={id:p.id,brand:txt(p.brand,80),name:txt(p.name,120),nameZh:txt(p.nameZh||p.name,120),concentration:txt(p.concentration,30),family:'官网补录',notes,intensity:[1,2,3].includes(p.intensity)?p.intensity:2,tags:(Array.isArray(p.tags)?p.tags:[]).filter(k=>['focus','calm','confidence','connection','energy','creativity'].includes(k)),online:true,recommendable:p.recommendable!==false&&Object.values(notes).some(x=>x.length),sourceUrl:txt(p.sourceUrl,1000),sourceTitle:txt(p.sourceTitle,200),noteDisclosure:txt(p.noteDisclosure,250),evidenceNote:txt(p.evidenceNote,200),intensityNote:txt(p.intensityNote,180),verifiedDate:txt(p.verifiedDate,10)};
  for(const k of ['imagePath','imageSourceUrl','imageSourcePage'])if(/^https:\/\//.test(p[k]||''))r[k]=txt(p[k],1500);
  r.imageCredit=txt(p.imageCredit,150);return r;
 }
 function same(p,q){const norm=s=>s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]|[^a-z0-9]/g,'');return p.sourceUrl&&q.sourceUrl&&p.sourceUrl.replace('/en/','/').split('?')[0]===q.sourceUrl.replace('/en/','/').split('?')[0]||norm(p.brand)===norm(q.brand)&&norm(p.name)===norm(q.name)&&p.concentration===q.concentration;}
 function merge(p){p=clean(p);if(!p)return null;const old=publicCatalog().find(x=>x.id===p.id||same(x,p));if(old)return old;state.imported.push(p);for(const n of Object.values(p.notes).flat())noteAliases[p.id]=(noteAliases[p.id]||'')+' '+n;return p;}
 let controller=null,timer,seq=0,rows=[],busy=false,lastStatus='',importQueue=[];
 const status=(zh,en)=>{$('lookup-status').textContent=tr(zh,en);};
 function draw(){
  $('lookup-results').innerHTML=rows.map((r,i)=>{const p=display(r.record);return `<article class="lookup-result"><div class="lookup-image">${bottle(p)}</div><div><span class="perfume-brand">${esc(p.brand)}</span><h3>${esc(p.name)}</h3><p>${esc(p.concentration)}${r.local?' · '+tr('已在图鉴','In the atlas'):' · '+tr('官网查询结果','From the brand')}</p><small>${esc(C.allNotes(p).slice(0,6).join(' · ')||tr('官网香调待补充','Official notes not available yet'))}</small>${p.sourceUrl?link(p.sourceUrl,tr('核对产品页面','Check product page')):''}<button class="outline-button" data-lookup-add="${i}" ${state.owned.includes(p.id)?'disabled':''}>${state.owned.includes(p.id)?tr('✓ 已在香水柜','✓ In your wardrobe'):r.local?tr('＋ 收进香水柜','＋ Add to wardrobe'):tr('确认产品并加入','Confirm & add')}</button></div></article>`;}).join('');
 }
 async function search(force=false){
  const q=$('lookup-query').value.trim(),ticket=++seq;clearTimeout(timer);controller?.abort();rows=[];draw();
  if(q.length<2){status('输入至少两个字母或汉字。','Enter at least two characters.');return;}
  const local=publicCatalog().filter(p=>matches(p,q));
  if(local.length&&!force){rows=local.slice(0,12).map(record=>({record,local:true}));draw();status(`图鉴中找到 ${local.length} 款；请核对浓度与版本。`,`Found ${local.length} scents in the atlas. Check the concentration and version.`);$('lookup-results').insertAdjacentHTML('beforeend',`<button class="text-button" id="lookup-expand">${tr('继续联网查找同名或其他版本 ↗','Search online for other versions ↗')}</button>`);$('lookup-expand').onclick=()=>search(true);return;}
  status('图鉴未收录或正在查找其他版本，正在查询品牌官网…','Looking through supported brand catalogues…');controller=new AbortController();const currentController=controller;const timeout=setTimeout(()=>currentController.abort(),45000);
  try{
   const response=await fetch(base()+'/api/search?q='+encodeURIComponent(q),{signal:controller.signal,credentials:'omit'}),data=await response.json();if(ticket!==seq)return;
   if(!response.ok)throw Error(data.error||'SEARCH_UNAVAILABLE');
   rows=(data.results||[]).map(r=>({...r,record:clean(r.record)})).filter(r=>r.record);
   draw();
   if(rows.length)status(`从官网找到 ${rows.length} 款。核对产品后即可加入香水柜与公共图鉴。`,`Found ${rows.length} products. Confirm a match to add it to your wardrobe and the public atlas.`);
   else status('暂未找到可核实的产品。请用英文产品名重试，或先创建个人记录。','No verifiable match yet. Try the English product name or create a personal record.');
   if(data.failed?.length)$('lookup-status').textContent+=tr(` ${data.failed.length} 个品牌官网暂时无法访问。`,` ${data.failed.length} brand sources are temporarily unavailable.`);
  }catch(err){if(ticket!==seq)return;status(err.message==='RATE_LIMIT'?'查找次数较多，请稍等一分钟再试。':'暂时无法完成联网查找。你可以重试，或先保存个人记录。',err.message==='RATE_LIMIT'?'Please wait a minute before searching again.':'Online lookup is temporarily unavailable. Retry or keep a personal record.');}finally{clearTimeout(timeout);}
 }
 async function add(index,button){
  if(busy)return;const candidate=rows[index];if(!candidate)return;busy=true;button.disabled=true;
  try{
   let p=candidate.record;
   if(!candidate.local){status('正在保存产品与真实图片…','Saving the product and its photograph…');const r=await fetch(base()+'/api/catalog',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'omit',body:JSON.stringify({token:candidate.token})});const data=await r.json();if(!r.ok)throw Error(data.error||'SAVE_UNAVAILABLE');p=merge(data.product);if(!p)throw Error('INVALID_RESPONSE');}
   if(!state.owned.includes(p.id))state.owned.push(p.id);persist();refreshOptions();refreshOwnership();draw();status(candidate.local?'已收进你的香水柜。':'已加入你的香水柜与公共图鉴，其他访客也能查到这款香水。',candidate.local?'Added to your wardrobe.':'Added to your wardrobe and the public atlas for other visitors.');toast(tr('香水柜已更新。','Your wardrobe has been updated.'));
  }catch(err){button.disabled=false;status(err.message==='SEARCH_EXPIRED'?'搜索结果已过期，请重新查找后再添加。':'暂时无法保存，尚未加入公共图鉴，请稍后重试。',err.message==='SEARCH_EXPIRED'?'This search has expired. Search again before adding.':'Unable to save yet. The product has not been added to the public atlas; please retry.');}finally{busy=false;}
 }
 function open(q='',keepQueue=false){if(!keepQueue)importQueue=[];$('lookup-next').classList.toggle('hidden',!importQueue.length);rows=[];draw();$('lookup-query').value=q;$('lookup-status').textContent='';if(!$('lookup-dialog').open)$('lookup-dialog').showModal();$('lookup-query').focus();if(q.length>=2)search();}
 async function sync(){try{const r=await fetch(base()+'/api/catalog',{credentials:'omit',signal:AbortSignal.timeout(12000)});if(!r.ok)return;const d=await r.json();let changed=false;for(const p of (d.products||[]).slice(0,500)){const before=state.imported.length;merge(p);if(state.imported.length>before)changed=true;}if(changed){persist();refreshOptions();refreshOwnership();}}catch{}}
 function nextImport(){const p=importQueue.shift();if(p)open(p.brand+' '+p.name,true);}
 function reviewImport(records){importQueue=records.slice(0,200);nextImport();}
 function init(){
  $('lookup-next').addEventListener('click',nextImport);
  $('lookup-form').addEventListener('submit',e=>{e.preventDefault();search();});
  $('lookup-query').addEventListener('input',()=>{clearTimeout(timer);controller?.abort();seq++;timer=setTimeout(()=>search(),850);});
  $('lookup-results').addEventListener('click',e=>{const b=e.target.closest('[data-lookup-add]');if(b)add(Number(b.dataset.lookupAdd),b);});
  $('lookup-dialog').addEventListener('close',()=>{seq++;clearTimeout(timer);controller?.abort();});
  $('manual-record').addEventListener('click',()=>{const q=$('lookup-query').value;$('lookup-dialog').close();openCustom();$('custom-name').value=q;});
  document.addEventListener('error',e=>{if(e.target?.classList?.contains('product-photo')){e.target.outerHTML=`<div class="photo-placeholder"><span aria-hidden="true">◌</span><small>${tr('图片暂不可用','IMAGE UNAVAILABLE')}</small></div>`;}},true);
  sync();
 }
 return {clean,open,init,refresh:draw,sync,reviewImport};
})();
