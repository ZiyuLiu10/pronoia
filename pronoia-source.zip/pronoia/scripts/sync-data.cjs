const fs=require('node:fs');
const path=require('node:path');
for(const [name,globalName] of [['catalog','SCENT_CATALOG'],['evidence','SCENT_EVIDENCE'],['en','PRONOIA_EN_DATA'],['stories','PRONOIA_STORIES']]){
 const root=path.join(__dirname,'..','data');
 const data=JSON.parse(fs.readFileSync(path.join(root,name+'.json'),'utf8'));
 fs.writeFileSync(path.join(root,name+'.js'),'window.'+globalName+' = '+JSON.stringify(data).replace(/</g,'\\u003c')+';\n');
}
console.log('Browser data files regenerated from JSON.');
