/* Global city search. Only the city query is sent to Open-Meteo / GeoNames. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.PronoiaLocations=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const clean=v=>typeof v==='string'?v.trim().slice(0,120):'';
function normalizeCities(data){
 const seen=new Set();
 return (Array.isArray(data?.results)?data.results:[]).filter(p=>p&&/^PPL(?:A[2-5]?|C|G)?$/.test(p.feature_code)&&Number.isInteger(p.id)&&!seen.has(p.id)&&typeof p.latitude==='number'&&Number.isFinite(p.latitude)&&Math.abs(p.latitude)<=89.9&&typeof p.longitude==='number'&&Number.isFinite(p.longitude)&&Math.abs(p.longitude)<=180&&clean(p.name)&&clean(p.country)).map(p=>{
  seen.add(p.id);const name=clean(p.name),region=[...new Set([p.admin2,p.admin1].map(clean).filter(x=>x&&x!==name))].join(', '),country=clean(p.country);
  return {id:p.id,name,region,country,label:[name,region,country].filter(Boolean).join(', '),lat:p.latitude,lon:p.longitude,timezone:clean(p.timezone)};
 }).filter((p,i,a)=>a.findIndex(x=>x.id===p.id)===i).slice(0,10);
}
function mapUrl(query){const q=typeof query==='string'?query.trim().slice(0,500):'';return q?'https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(q):'';}
async function searchCities(query,language='zh',signal,fetcher=globalThis.fetch){
 const q=clean(query);if([...q].length<2)return [];
 const url=new URL('https://geocoding-api.open-meteo.com/v1/search');
 url.search=new URLSearchParams({name:q,count:'20',language:language==='en'?'en':'zh',format:'json'});
 const response=await fetcher(url.toString(),{signal,credentials:'omit',referrerPolicy:'no-referrer'});
 if(!response.ok)throw Error('City search unavailable');
 const data=await response.json();if(data.error)throw Error('City search unavailable');
 return normalizeCities(data);
}
function createPicker({input,list,status,map,getLanguage,onChange}){
 let selected=null,items=[],active=-1,timer,controller,revision=0,mode='idle',composing=false;
 const cache=new Map(),t=(zh,en)=>getLanguage()==='en'?en:zh;
 const statusText=()=>({idle:t('输入城市名，从结果中选择出生城市。','Type a city name, then choose your birth city.'),short:t('请输入至少 2 个字或字母。','Enter at least 2 characters.'),loading:t('正在寻找城市…','Searching for cities…'),results:t(`找到 ${items.length} 个地点，请核对地区与国家后选择。`,`Found ${items.length} places. Check the region and country before choosing.`),empty:t('未找到城市。试试英文名称，或输入「城市, 国家」。','No cities found. Try the English name, or “city, country”.'),error:t('城市搜索暂不可用，请稍后重试。也可先在 Google Maps 核对城市名称。','City search is unavailable. Try again shortly, or check the city name on Google Maps.'),selected:t('已选择：','Selected: ')+(selected?.label||'')+(selected?.timezone?t(' · 时区：',' · Time zone: ')+selected.timezone:'')})[mode];
 function updateMap(){const url=mapUrl(selected?.label||input.value);map.hidden=!url;if(url)map.href=url;else map.removeAttribute('href');map.textContent=t('在 Google Maps 查看 ↗','View on Google Maps ↗');}
 function close(){list.hidden=true;input.setAttribute('aria-expanded','false');input.removeAttribute('aria-activedescendant');active=-1;}
 function render(){status.textContent=statusText();input.setAttribute('aria-busy',String(mode==='loading'));updateMap();}
 function cancel(){revision++;clearTimeout(timer);controller?.abort();controller=null;}
 function choose(index){const city=items[index];if(!city)return;cancel();selected=city;input.value=city.label;input.removeAttribute('aria-invalid');mode='selected';close();render();onChange(city);input.focus({preventScroll:true});}
 function show(){
  list.replaceChildren();active=-1;input.removeAttribute('aria-activedescendant');
  items.forEach((city,i)=>{const option=document.createElement('div');option.id='birth-city-option-'+i;option.setAttribute('role','option');option.setAttribute('aria-selected','false');option.className='city-option';const name=document.createElement('strong'),detail=document.createElement('span');name.textContent=city.name;detail.textContent=[city.region,city.country].filter(Boolean).join(' · ');option.append(name,detail);option.addEventListener('mousedown',e=>e.preventDefault());option.addEventListener('click',()=>choose(i));list.append(option);});
  const open=items.length>0&&document.activeElement===input;list.hidden=!open;input.setAttribute('aria-expanded',String(open));
 }
 async function run(){
  const query=input.value.trim();if([...query].length<2){mode=query?'short':'idle';close();render();return;}
  cancel();const ticket=revision,language=getLanguage(),key=language+'|'+query.toLocaleLowerCase();controller=new AbortController();const ownController=controller,timeout=setTimeout(()=>ownController.abort(),10000);
  mode='loading';close();render();
  try{const result=cache.get(key)||await searchCities(query,language,ownController.signal);if(ticket!==revision)return;items=result;if(!cache.has(key)){if(cache.size>=40)cache.delete(cache.keys().next().value);cache.set(key,result);}mode=items.length?'results':'empty';show();render();}
  catch(e){if(ticket!==revision)return;items=[];mode='error';close();render();}
  finally{clearTimeout(timeout);if(ticket===revision)controller=null;}
 }
 function edited(){cancel();selected=null;items=[];input.removeAttribute('aria-invalid');close();onChange(null);mode=input.value.trim()?'short':'idle';if([...input.value.trim()].length>=2){mode='loading';if(!composing)timer=setTimeout(run,350);}render();}
 input.addEventListener('input',edited);
 input.addEventListener('compositionstart',()=>{composing=true;cancel();});input.addEventListener('compositionend',()=>{composing=false;edited();});
 input.addEventListener('keydown',e=>{
  if(e.isComposing||composing)return;
  if(e.key==='Escape'){cancel();close();mode=selected?'selected':items.length?'results':'idle';render();return;}
  if(e.key==='Enter'&&!selected){e.preventDefault();if(active>=0&&!list.hidden)choose(active);else run();return;}
  if((e.key==='ArrowDown'||e.key==='ArrowUp')&&items.length){e.preventDefault();list.hidden=false;input.setAttribute('aria-expanded','true');active=active<0?(e.key==='ArrowDown'?0:items.length-1):(active+(e.key==='ArrowDown'?1:-1)+items.length)%items.length;[...list.children].forEach((el,i)=>el.setAttribute('aria-selected',String(i===active)));input.setAttribute('aria-activedescendant',list.children[active].id);list.children[active].scrollIntoView({block:'nearest'});}
 });
 input.addEventListener('focus',()=>{if(!selected&&items.length)show();});input.addEventListener('blur',()=>setTimeout(()=>{if(document.activeElement!==input)close();},150));
 render();
 return {getSelected:()=>selected,refresh:()=>{cancel();if(!selected&&input.value.trim()){items=[];run();}else render();},requireSelection:()=>{if(!selected){input.closest('details').open=true;input.setAttribute('aria-invalid','true');input.focus({preventScroll:true});throw Error(t('请从搜索结果中选择出生城市，再计算完整星盘。','Choose your birth city from the search results to calculate a full chart.'));}return selected;}};
}
return {normalizeCities,mapUrl,searchCities,createPicker};
});
