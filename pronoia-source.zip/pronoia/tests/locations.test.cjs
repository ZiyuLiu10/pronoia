'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const L=require('../locations.js'),C=require('../core.js'),A=require('../vendor/astronomy.browser.min.js');
const paris={id:2988507,name:'Paris',admin1:'Île-de-France',country:'France',latitude:48.8534,longitude:2.3488,timezone:'Europe/Paris',feature_code:'PPLC'};
test('city results retain region and country, reject non-city and invalid coordinates',()=>{
 const cities=L.normalizeCities({results:[paris,{...paris,id:2,country:'United States',admin1:'Texas'},paris,{...paris,id:3,feature_code:'ISL'},{...paris,id:4,feature_code:'PPLH'},{...paris,id:5,latitude:NaN},{...paris,id:6,longitude:181},{...paris,id:7,latitude:null},{...paris,id:8,name:''},null]});
 assert.equal(cities.length,2);assert.equal(cities[0].label,'Paris, Île-de-France, France');assert.equal(cities[1].label,'Paris, Texas, United States');assert.equal(cities[0].timezone,'Europe/Paris');
});
test('Google Maps link safely encodes the complete chosen city',()=>{
 const city=L.normalizeCities({results:[paris]})[0],url=new URL(L.mapUrl(city.label));assert.equal(url.origin,'https://www.google.com');assert.equal(url.searchParams.get('query'),city.label);assert.equal(url.searchParams.get('api'),'1');assert.equal(L.mapUrl('  '),'');assert.equal(new URL(L.mapUrl('São Paulo & <test>')).searchParams.get('query'),'São Paulo & <test>');
});
test('global search transmits only query parameters and no browser credentials',async()=>{
 let calls=0;const signal=new AbortController().signal;
 const cities=await L.searchCities('上海','zh',signal,async(url,options)=>{calls++;const u=new URL(url);assert.equal(u.hostname,'geocoding-api.open-meteo.com');assert.equal(u.searchParams.get('name'),'上海');assert.equal(u.searchParams.get('language'),'zh');assert.deepEqual([...u.searchParams.keys()],['name','count','language','format']);assert.equal(options.credentials,'omit');assert.equal(options.referrerPolicy,'no-referrer');assert.equal(options.signal,signal);return {ok:true,json:async()=>({results:[paris]})};});
 assert.equal(calls,1);assert.equal(cities.length,1);await L.searchCities('a','en',signal,()=>{throw Error('Must not query one character');});
});
test('unavailable and malformed search responses never invent a selected location',async()=>{
 await assert.rejects(L.searchCities('Paris','en',undefined,async()=>({ok:false})),/unavailable/);
 await assert.rejects(L.searchCities('Paris','en',undefined,async()=>({ok:true,json:async()=>({error:true})})),/unavailable/);
 assert.deepEqual(await L.searchCities('Paris','en',undefined,async()=>({ok:true,json:async()=>({results:'bad'})})),[]);
});
test('selected city coordinates feed the existing full-chart calculation unchanged',()=>{
 const city=L.normalizeCities({results:[paris]})[0];const birth={date:'1998-05-16',time:'12:30',offset:2};
 const fromCity=C.birthChart({...birth,lat:city.lat,lon:city.lon},A),explicit=C.birthChart({...birth,lat:48.8534,lon:2.3488},A);
 assert.deepEqual(fromCity,explicit);assert.ok(fromCity.asc);assert.ok(fromCity.moon);assert.equal(fromCity.placements.length,10);
});
