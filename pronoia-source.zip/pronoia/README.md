# Pronoia

Hakuna Matata 无忧无虑，梦想成真。

中英文香水推荐网页：本命香、阶段目标、重要场合；每次最多 3 款，叠喷最多 2 款。基础图鉴包含 16 个品牌、200 款独立香水版本与真实产品照片，支持品牌/香调搜索和分页。个人香水柜、日程及偏好保存在浏览器中；支持 JSON 导入导出。

## 本地与 GitHub Pages

直接打开 `index.html`，或使用 `python3 -m http.server 8765`。源码无需 npm 或构建。单文件交付 `Pronoia.html` 把代码、图鉴、200 张照片与主页艺术图全部内嵌，离线也可选香。

把本目录全部上传到 GitHub 仓库；在 Settings → Pages 选择 GitHub Actions，使用已提供的 `.github/workflows/pages.yml`。也可使用 Deploy from a branch，选择 `main` / `(root)`。

联网功能通过 `config.js` 中的 `PRONOIA_API` 访问独立后台。GitHub Pages 本身不写入数据库，切勿在前端填写私密 API 密钥。若自行部署后台，将这个公开地址替换成自己的 HTTPS 服务域名。

## 联网补录

“我的香水柜 → 添加自己的香水”先检索本地图鉴；未找到时自动查询支持的品牌官网。输入英文名称效果最好。核对产品与浓度后确认，服务器保存官方记录和图片，并加入公共图鉴；其他访客下次打开页面即可读取。

支持 12 家公开目录：Etat Libre d’Orange、BDK、Maison Crivelli、Essential Parfums、Amouage、Parfums de Marly、Memo、Floris、D.S. & Durga、Histoires de Parfums、Vilhelm、Xerjoff。搜索不是覆盖全网的通用搜索引擎。未接入品牌、官网拒绝或暂不可用时，允许保存个人记录，但不会公开未核实内容。没有可靠香调的官网产品可收藏，暂不参加推荐。后台共享补录容量为 500 条；基础 200 条不占此容量。

服务器只接收查找关键词和确认产品所需的短期令牌，不接收出生资料、个人目标或整个私人香水柜。手动填写的个人档案不会上传。导入备份中的个人档案会打开官网核对流程，确认之前保持本地。

## 数据与推荐

- `data/catalog.json`：200 款中文香调、具体浓度、官网来源及图片。
- `data/en.json`：完整英文内容与香材词汇。
- `data/image-credits.json`：逐图出处及权利说明。
- `data/evidence.json`、`RESEARCH.md`：研究与历史文化资料；网页没有“灵感与依据”栏目。
- `core.js`：可解释的编辑规则；不是成功概率、心理治疗或运气预测。
- `online.js`：公共图鉴客户端；自填数据与官网资料分别保存。

修改 JSON 后运行 `node scripts/sync-data.cjs`。运行算法检查：`node --test tests/core.test.cjs`。后端源码、迁移与测试位于交付的 `pronoia-backend` 项目。

## 图片与许可

200 张实物产品图：180 张来自品牌官方公开商品图，20 张来自零售商商品页。图片大小或地区包装可能不同；对应浓度已核对。Passage d’Enfer 的照片为旧版透明瓶。全部照片存储在网站资产目录，不依赖首次加载时热链。

代码采用 MIT 许可。产品照片、品牌标志和商标仍归相应品牌、零售商与摄影者所有，不包含在 MIT 授权内；逐图出处见 `data/image-credits.json`。主页超现实艺术图为专门生成的视觉资产。
