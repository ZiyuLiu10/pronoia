/* Pronoia's documented Western astrology-to-fragrance interpretation.
   Positions are astronomical calculations. Correspondences and scoring are
   interpretive rules, not measured effects or event-success probabilities. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.PronoiaAstrology=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const SOURCE='https://www.esotericarchives.com/agrippa/op1.htm';
const HOUSE_SOURCE='https://www.skyscript.co.uk/lilly_houses.html';
const PLANETS={Sun:{zh:'太阳',en:'Sun'},Moon:{zh:'月亮',en:'Moon'},Mercury:{zh:'水星',en:'Mercury'},Venus:{zh:'金星',en:'Venus'},Mars:{zh:'火星',en:'Mars'},Jupiter:{zh:'木星',en:'Jupiter'},Saturn:{zh:'土星',en:'Saturn'}};
const RULERS=['Mars','Venus','Mercury','Moon','Sun','Mercury','Venus','Mars','Jupiter','Saturn','Saturn','Jupiter'];
const EXALTATION={Sun:0,Moon:1,Mercury:5,Venus:11,Mars:9,Jupiter:3,Saturn:6};
const ASPECTS=[{angle:0,zh:'合相',en:'conjunction'},{angle:60,zh:'六合',en:'sextile'},{angle:90,zh:'刑相',en:'square'},{angle:120,zh:'拱相',en:'trine'},{angle:180,zh:'对冲',en:'opposition'}];
const norm=x=>((x%360)+360)%360;
const distance=(a,b)=>Math.abs(((a-b+540)%360)-180);
// The first group names materials in Agrippa I.44 (Venus sandalwood: I.28).
// The second group adapts his broader plant-part categories to modern scent notes.
// These are note-name correspondences, never claims about actual ingredients.
const CORRESPONDENCES={
 Sun:{direct:/乳香|(?<!红)没药|藏红花|麝香|安息香|苏合香|岩蔷薇|劳丹脂|沉香|龙涎香香调|\b(?:frankincense|olibanum|myrrh|saffron|musk|benzoin|storax|styrax|labdanum|oud|agarwood|ambergris|clove|cloves|mastic)\b|丁香|乳香黄连木树脂/i,adapted:/焚香|树脂|香脂|\b(?:incense|resin|balsam)\b/i},
 Moon:{direct:/乳香(?!黄连木)|樟脑|桃金娘|月桂叶|\b(?:frankincense|olibanum|camphor|myrtle)\b|\bbay leaf\b/i,adapted:/无花果叶|苦橙叶|紫罗兰叶|茶叶|红茶|绿茶|\b(?:petitgrain|tea)\b|\b(?:fig|violet) lea(?:f|ves)\b/i},
 Mercury:{direct:/肉桂|肉豆蔻衣|柠檬皮|月桂果|乳香|丁香|乳香黄连木树脂|\b(?:cinnamon|cassia|mace|mastic|frankincense|olibanum|cloves?)\b|\b(?:citron|lemon) peel\b|\bbayberries\b/i,adapted:/佛手柑|柠檬|柑橘|葡萄柚|橘|柚子|豆蔻|孜然|芫荽|\b(?:bergamot|lemon|citrus|grapefruit|mandarin|yuzu|cardamom|cumin|coriander)\b/i},
 Venus:{direct:/玫瑰(?!木)|紫罗兰(?!叶)|藏红花|麝香|龙涎香香调|沉香|檀香|\b(?:rose|roses|saffron|musk|ambergris|oud|agarwood|sandalwood)\b|\bviolets?\b(?!\s+lea(?:f|ves)\b)/i,adapted:/茉莉|橙花|晚香玉|牡丹|鸢尾(?!根)|依兰|桂花|铃兰|小苍兰|白花|\b(?:jasmine|neroli|tuberose|peony|iris|ylang|osmanthus|freesia)\b|\b(?:orange blossom|lily of the valley|white florals)\b/i},
 Mars:{direct:/檀香|柏树|沉香|\b(?:sandalwood|cypress|oud|agarwood)\b/i,adapted:/雪松|愈创木|木质|\b(?:cedar|cedarwood|guaiac|wood|woody)\b/i},
 Jupiter:{direct:/肉豆蔻(?!衣)|丁香|安息香|苏合香|沉香|\b(?:nutmeg|cloves?|benzoin|storax|styrax|oud|agarwood)\b/i,adapted:/无花果(?!叶)|梨|苹果|桃|李子|杏|黑莓|覆盆子|荔枝|\b(?:fig|pear|apple|peach|plum|apricot|blackberry|raspberry|lychee)\b/i},
 Saturn:{direct:/(?<!红)没药|木香根|\bmyrrh\b|\bcostus\b/i,adapted:/香根草|岩兰草|鸢尾根|\b(?:vetiver|orris)\b/i}
};
// I.44 gives a separate zodiac incense list; it is not interchangeable with
// planetary rulership. Unavailable historical materials are left unmatched.
const SIGN_INCENSE=[
 {zh:'没药',en:'myrrh',re:/(?<!红)没药|\bmyrrh\b/i},
 {zh:'木香根',en:'costus',re:/木香根|\bcostus\b/i},
 {zh:'乳香黄连木树脂',en:'mastic',re:/乳香黄连木树脂|\bmastic\b/i},
 {zh:'樟脑',en:'camphor',re:/樟脑|\bcamphor\b/i},
 {zh:'乳香',en:'frankincense',re:/乳香(?!黄连木)|\b(?:frankincense|olibanum)\b/i},
 {zh:'檀香',en:'sandalwood',re:/檀香|\bsandalwood\b/i},
 {zh:'白松香',en:'galbanum',re:/白松香|\bgalbanum\b/i},
 {zh:'红没药',en:'opoponax',re:/红没药|\bopoponax\b/i},
 {zh:'沉香',en:'agarwood',re:/沉香|\b(?:oud|agarwood)\b/i},
 {zh:'安息香',en:'benzoin',re:/安息香|\bbenzoin\b/i},
 {zh:'大戟树脂',en:'euphorbium',re:/大戟树脂|\beuphorbium\b/i},
 {zh:'苏合香',en:'storax',re:/苏合香|\b(?:storax|styrax)\b/i}
];
const THEMES={
 startup:{planets:{Sun:1,Mars:.8,Jupiter:.8},houses:[10,2]},
 growth:{planets:{Mercury:1,Jupiter:.8,Saturn:.5},houses:[9,3]},
 relationship:{planets:{Venus:1,Moon:.6},houses:[7,5]},
 reset:{planets:{Moon:1,Venus:.5},houses:[1,4]},
 study:{planets:{Mercury:1,Saturn:.7},houses:[3,9]},
 interview:{planets:{Mercury:1,Sun:.8},houses:[10,3]},
 client:{planets:{Mercury:1,Venus:.7},houses:[7,10]},
 date:{planets:{Venus:1,Moon:.7},houses:[5,7]},
 presentation:{planets:{Sun:1,Mercury:1},houses:[10,3]},
 creative:{planets:{Venus:1,Mercury:.6},houses:[5]},
 social:{planets:{Venus:1,Jupiter:.7},houses:[11,7]},
 custom:{planets:{},houses:[]}
};
function longitude(A,body,date){if(body==='Sun')return norm(A.SunPosition(date).elon);if(body==='Moon')return norm(A.EclipticGeoMoon(date).lon);return norm(A.Ecliptic(A.GeoVector(body,date,true)).elon);}
function position(A,body,date){const lon=longitude(A,body,date),before=longitude(A,body,new Date(date.getTime()-43200000)),after=longitude(A,body,new Date(date.getTime()+43200000));return {body,longitude:lon,index:Math.floor(lon/30),degree:lon%30,retrograde:!['Sun','Moon'].includes(body)&&((after-before+540)%360)-180<0};}
function aspect(a,b,orb=6){const separation=distance(a,b),found=ASPECTS.find(x=>Math.abs(separation-x.angle)<=orb);return found?{...found,separation,orb:Math.abs(separation-found.angle),strength:Math.max(0,1-Math.abs(separation-found.angle)/orb)}:null;}
function dignity(body,index){if(RULERS[index]===body)return {kind:'domicile',factor:1.15};if(EXALTATION[body]===index)return {kind:'exaltation',factor:1.08};if(RULERS[(index+6)%12]===body)return {kind:'detriment',factor:.9};if((EXALTATION[body]+6)%12===index)return {kind:'fall',factor:.94};return {kind:'neutral',factor:1};}
function enrichChart(chart,A){
 const date=new Date(chart.utc),planets={};
 if(chart.complete){for(const body of Object.keys(PLANETS)){const p=position(A,body,date);planets[body]={...p,house:chart.asc?(p.index-chart.asc.index+12)%12+1:null,dignity:dignity(body,p.index)};}}
 else if(!chart.uncertain)planets.Sun={body:'Sun',longitude:chart.sun.longitude,index:chart.sun.index,degree:chart.sun.degree,house:null,dignity:dignity('Sun',chart.sun.index),approximate:true,retrograde:false};
 const aspects=[];if(chart.complete){const keys=Object.keys(planets);keys.forEach((a,i)=>keys.slice(i+1).forEach(b=>{const hit=aspect(planets[a].longitude,planets[b].longitude,['Sun','Moon'].some(x=>a===x||b===x)?8:6);if(hit)aspects.push({a,b,...hit});}));}
 return {...chart,planets,aspects,houseSystem:chart.asc?'whole-sign':null,chartRuler:chart.asc?RULERS[chart.asc.index]:null};
}
function skyAt(input,A){
 if(!A)throw Error('星位计算模块未加载。');
 const value=input.date||'',time=input.time||'12:00';if(!/^\d{4}-\d{2}-\d{2}$/.test(value)||!/^\d{2}:\d{2}$/.test(time))throw Error('请核对目标日期与参考时间。');
 const [y,m,d]=value.split('-').map(Number),[h,min]=time.split(':').map(Number),offset=Number(input.offset),check=new Date(Date.UTC(y,m-1,d));
 if(check.getUTCFullYear()!==y||check.getUTCMonth()!==m-1||check.getUTCDate()!==d||y<1900||y>2100||h>23||min>59||input.offset===''||input.offset===null||!Number.isFinite(offset)||offset< -12||offset>14)throw Error('日期需在 1900–2100 年内，且时间与时差有效。');
 const date=new Date(Date.UTC(y,m-1,d,h,min)-offset*3600000),planets={};for(const body of Object.keys(PLANETS))planets[body]=position(A,body,date);
 return {date:value,time,offset,utc:date.toISOString(),assumedNoon:!input.time,planets};
}
function buildTarget(chart,ctx={}){
 const signals=[],planets=chart.planets||{},add=(planet,weight,meta)=>{if(PLANETS[planet]&&weight>0)signals.push({planet,weight,...meta});};
 const base={Sun:.9,Moon:1,Mercury:.65,Venus:1.5,Mars:.5,Jupiter:.45,Saturn:.4};
 for(const [body,p] of Object.entries(planets)){
  const natalAspects=(chart.aspects||[]).filter(a=>a.a===body||a.b===body),salience=1+Math.min(.3,natalAspects.reduce((s,a)=>s+.06*a.strength,0));
  const weight=(base[body]||.4)*(p.dignity?.factor||1)*salience;
  add(body,weight,{kind:'natal',body,position:p,aspects:natalAspects});
  add(RULERS[p.index],weight*.45,{kind:'dispositor',body,position:p});
  signals.push({kind:'zodiac',body,index:p.index,position:p,weight:weight*.45});
 }
 if(chart.chartRuler)add(chart.chartRuler,1.4,{kind:'ascendant',index:chart.asc.index,position:planets[chart.chartRuler]});
 const topics=[];if(ctx.level>=2)topics.push({key:ctx.goalKey||'custom',weight:ctx.level===3?.45:1});if(ctx.level===3)topics.push({key:ctx.eventKey||'custom',weight:1});
 for(const topic of topics){const theme=THEMES[topic.key]||THEMES.custom;
  for(const [body,w] of Object.entries(theme.planets)){
   // Follow this person's planetary placement and its ruler, not just the topic label.
   add(body,w*topic.weight,{kind:'theme',topic:topic.key,position:planets[body]});
   if(planets[body])add(RULERS[planets[body].index],w*.6*topic.weight,{kind:'theme-dispositor',body,topic:topic.key,position:planets[body]});
  }
  if(chart.asc)for(const house of theme.houses){const index=(chart.asc.index+house-1)%12;add(RULERS[index],1.1*topic.weight,{kind:'house',house,index,topic:topic.key,position:planets[RULERS[index]]});}
 }
 const transits=[];if(ctx.level>=2&&ctx.sky){
  // Reference-time Moon and relevant planets add a time-dependent scent theme.
  const lunar=ctx.sky.planets.Moon;if(lunar){add(RULERS[lunar.index],.9,{kind:'sky',body:'Moon',position:lunar,date:ctx.sky.date,time:ctx.sky.time});signals.push({kind:'zodiac',body:'Moon',index:lunar.index,position:lunar,weight:.4,transiting:true,date:ctx.sky.date,time:ctx.sky.time});}
  if(chart.complete)for(const [a,t] of Object.entries(ctx.sky.planets))for(const [b,n] of Object.entries(planets)){
   const hit=aspect(t.longitude,n.longitude,3);if(!hit)continue;
   const relevant=topics.reduce((s,topic)=>s+((THEMES[topic.key]||THEMES.custom).planets[b]||0)*topic.weight,0);
   const transit={a,b,...hit,date:ctx.sky.date,time:ctx.sky.time,transiting:t,natal:n};transits.push(transit);
   add(b,(.15+.35*relevant)*hit.strength,{kind:'transit',transit,position:n});
  }
 }
 return {signals,transits,source:SOURCE,houseSource:HOUSE_SOURCE,available:Object.keys(planets).length>0,complete:chart.complete,houseSystem:chart.houseSystem};
}
function match(perfume,target){
 const notes=[...new Set(Object.values(perfume.notes||{}).flat().filter(x=>typeof x==='string'))],matches=[],wanted={},offered={};let zodiacPoints=0,zodiacTotal=0;
 for(const signal of target.signals){let hits=[],strength=0,adapted=false;
  if(signal.kind==='zodiac'){hits=notes.filter(n=>SIGN_INCENSE[signal.index].re.test(n));strength=hits.length?1:0;}
  else {const rule=CORRESPONDENCES[signal.planet];if(!rule)continue;hits=notes.filter(n=>rule.direct.test(n));if(hits.length)strength=Math.min(1,.85+.15*(hits.length-1));else {hits=notes.filter(n=>rule.adapted.test(n));strength=hits.length?.5:0;adapted=!!hits.length;}}
  if(signal.kind==='zodiac'){zodiacTotal+=signal.weight;zodiacPoints+=signal.weight*strength;}
  else {wanted[signal.planet]=(wanted[signal.planet]||0)+signal.weight;offered[signal.planet]=strength;}
  if(hits.length)matches.push({...signal,notes:hits.slice(0,3),adapted,contribution:signal.weight*strength});
 }
 // Compare the direction of the planetary profiles. Merely listing more notes
 // must not automatically beat a focused scent with a closer planetary balance.
 for(const [planet,rule] of Object.entries(CORRESPONDENCES)){const direct=notes.filter(n=>rule.direct.test(n)).length;offered[planet]=direct?Math.min(1,.85+.15*(direct-1)):notes.some(n=>rule.adapted.test(n))?.5:0;}
 const keys=Object.keys(PLANETS),dot=keys.reduce((s,k)=>s+(wanted[k]||0)*offered[k],0),denominator=Math.sqrt(keys.reduce((s,k)=>s+(wanted[k]||0)**2,0)*keys.reduce((s,k)=>s+offered[k]**2,0));
 const planetaryScore=denominator?dot/denominator*Math.max(...Object.values(offered)):0,zodiacScore=zodiacTotal?zodiacPoints/zodiacTotal:0,score=zodiacTotal?.85*planetaryScore+.15*zodiacScore:planetaryScore;
 matches.sort((a,b)=>b.contribution-a.contribution);
 return {score:Math.max(0,Math.min(1,score)),planetaryScore,zodiacScore,matches,matched:matches.length>0};
}
return {SOURCE,HOUSE_SOURCE,PLANETS,RULERS,EXALTATION,ASPECTS,CORRESPONDENCES,SIGN_INCENSE,THEMES,distance,aspect,dignity,position,enrichChart,skyAt,buildTarget,match};
});
