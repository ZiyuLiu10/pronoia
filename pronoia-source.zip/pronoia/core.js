/* Pronoia: deterministic, inspectable editorial recommendation rules. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.ScentCore=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const ASTRO=typeof module==='object'&&module.exports?require('./astrology.js'):globalThis.PronoiaAstrology;
const TAGS={focus:'专注',calm:'安定',confidence:'自信',connection:'亲和',energy:'活力',creativity:'灵感'};
// Feelings blend the existing six editorial axes; catalogue tags keep their original meaning.
const FEELINGS={
 focus:{zh:'专注',en:'Focused',vector:[1,0,0,0,0,0],words:'专注|集中|focus(?:ed)?|concentrat(?:e|ed|ion)'},
 calm:{zh:'安定',en:'Calm',vector:[0,1,0,0,0,0],words:'安定|安心|平静|宁静|calm|peaceful|tranquil'},
 confidence:{zh:'自信',en:'Confident',vector:[0,0,1,0,0,0],words:'自信|有力量|底气|confiden(?:t|ce)|empowered'},
 connection:{zh:'亲和',en:'Approachable',vector:[0,0,0,1,0,0],words:'亲和|亲切|友善|approachable|friendly|welcoming'},
 energy:{zh:'活力',en:'Energised',vector:[0,0,0,0,1,0],words:'活力|元气|精神饱满|energi[sz]ed|energetic|vibrant'},
 creativity:{zh:'灵感',en:'Inspired',vector:[0,0,0,0,0,1],words:'灵感|创造力|inspir(?:ed|ation)|creative'},
 relaxed:{zh:'松弛',en:'Relaxed',vector:[0,1,0,.25,.1,.15],words:'松弛|放松|自在|relax(?:ed|ing)?|laid.back|at ease'},
 joyful:{zh:'愉悦',en:'Joyful',vector:[0,.2,.15,.5,1,.2],words:'愉悦|快乐|开心|joyful|happy|cheerful'},
 romantic:{zh:'浪漫',en:'Romantic',vector:[0,.25,.15,1,.1,.55],words:'浪漫|心动|romantic|romance'},
 gentle:{zh:'温柔',en:'Gentle',vector:[0,.7,0,1,0,.2],words:'温柔|柔和|柔软|gentle|soft|tender'},
 clear:{zh:'清醒',en:'Clear-minded',vector:[1,.35,.1,0,.55,.1],words:'清醒|清晰|清明|clear.minded|clarity|alert'},
 brave:{zh:'勇敢',en:'Brave',vector:[.3,0,1,.1,.7,.2],words:'勇敢|勇气|大胆|brave|courage(?:ous)?|bold'},
 free:{zh:'自由',en:'Free-spirited',vector:[0,.15,.35,.15,.6,1],words:'自由|无拘无束|洒脱|free.spirited|freedom|carefree'},
 mysterious:{zh:'神秘',en:'Mysterious',vector:[.25,.35,.65,.1,0,1],words:'神秘|深邃|mysterious|enigmatic'},
 elegant:{zh:'优雅',en:'Elegant',vector:[.45,.4,.85,.65,0,.15],words:'优雅|高级|知性|elegant|refined|sophisticated'},
 grounded:{zh:'沉稳',en:'Grounded',vector:[.65,1,.6,0,0,.1],words:'沉稳|稳重|踏实|grounded|steady|composed'},
 comforting:{zh:'治愈',en:'Comforting',vector:[.1,1,0,.7,0,.1],words:'治愈|慰藉|被拥抱|comfort(?:ing)?|cosy|cozy|reassuring'},
 fresh:{zh:'清新',en:'Fresh',vector:[.55,.35,0,.2,1,.2],words:'清新|清爽|干净|fresh|clean|crisp'},
 sensual:{zh:'性感',en:'Sensual',vector:[0,.15,1,.85,.2,.25],words:'性感|妩媚|撩人|sensual|sexy|seductive'},
 playful:{zh:'俏皮',en:'Playful',vector:[0,0,.35,.75,1,.7],words:'俏皮|灵动|可爱|playful|whimsical|cute'},
 independent:{zh:'独立',en:'Independent',vector:[.7,.15,1,0,.2,.55],words:'独立|做自己|自主|independent|self.assured|individual'},
 balanced:{zh:'平衡',en:'Balanced',vector:[.5,1,.35,.5,.15,.25],words:'平衡|和谐|balanced|harmony|harmonious'},
 hopeful:{zh:'希望',en:'Hopeful',vector:[.15,.3,.65,.2,.75,1],words:'希望|期待|乐观|hopeful|optimistic|optimism'},
 warm:{zh:'温暖',en:'Warm',vector:[0,.8,.15,1,.25,0],words:'温暖|暖意|暖暖|warm|warmth'}
};
function parseFeelings(text=''){
 // Explicit keyword matching, not an open-ended language model. Ignore negated clauses.
 const clauses=String(text).slice(0,160).split(/[，,。.;；!?！？\n]|但是|不过|但|而是|\bbut\b|\binstead\b/i);
 const positive=clauses.filter(s=>!/(?:不要|不想|不喜欢|不需要|不太|不够|不再|避免|拒绝|没有|缺少|并非|不必|不求|非要|^\s*不|\b(?:not|no|without|avoid|less)\b|don['’]?t)/i.test(s));
 return Object.entries(FEELINGS).filter(([,f])=>positive.some(s=>new RegExp('(?:^|[^a-z])(?:'+f.words+')(?![a-z])','i').test(s))).map(([id])=>id);
}
function preferenceVector(likes=[],text=''){
 const ids=[...new Set([...(Array.isArray(likes)?likes:[]),...parseFeelings(text)])].filter(id=>Object.hasOwn(FEELINGS,id));
 if(!ids.length)return null;
 // Each selected feeling contributes equally, even when its blend has more dimensions.
 return ids.reduce((v,id)=>{const a=FEELINGS[id].vector,total=a.reduce((s,x)=>s+x,0);return v.map((x,i)=>x+a[i]/total/ids.length);},[0,0,0,0,0,0]);
}
const SIGNS=['白羊','金牛','双子','巨蟹','狮子','处女','天秤','天蝎','射手','摩羯','水瓶','双鱼'];
const GLYPHS=['♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓'];
const ELEMENTS=['火','土','风','水'];
const ELEMENT_VECTORS={火:[.4,.2,1,.55,1,.65],土:[1,.9,.65,.4,.3,.4],风:[.6,.4,.5,.9,.65,1],水:[.4,1,.4,1,.3,.7]};
const GOALS={startup:{label:'创业与事业',vector:[.75,.4,1,.8,.8,.85],action:'选出一个最小可验证的下一步，给它一个截止时间。'},growth:{label:'学习与成长',vector:[1,.7,.55,.4,.65,.85],action:'开始一段 25 分钟的专注时间，完成一个具体任务。'},relationship:{label:'建立关系',vector:[.3,.7,.6,1,.5,.55],action:'准备一个真诚的问题，给对方留下表达的空间。'},reset:{label:'重新找回状态',vector:[.5,1,.5,.5,.6,.6],action:'选一件今天可完成的小事，允许自己从小处开始。'},custom:{label:'自定义目标',vector:[.6,.6,.6,.6,.6,.6],action:'把愿望改写成一件今天能够完成的行动。'}};
const EVENTS={study:{label:'写作 / 深度学习',vector:[1,.8,.3,.2,.35,.7],max:2},interview:{label:'面试 / 学术交流',vector:[.85,.7,1,.75,.45,.5],max:2},client:{label:'客户面谈',vector:[.7,.65,.9,1,.4,.35],max:2},date:{label:'约会 / 见喜欢的人',vector:[.25,.65,.75,1,.4,.6],max:2},presentation:{label:'演讲 / 路演',vector:[.8,.5,1,.7,.8,.5],max:2},creative:{label:'创作 / 自由探索',vector:[.6,.5,.6,.5,.7,1],max:3},social:{label:'聚会 / 社交',vector:[.2,.4,.85,1,.85,.7],max:3},custom:{label:'其他重要的事',vector:[.6,.6,.6,.6,.6,.6],max:2}};
const WEIGHTS={1:{astro:.65,goal:0,event:0,preference:.35},2:{astro:.55,goal:.25,event:0,preference:.2},3:{astro:.5,goal:.1,event:.25,preference:.15}};
const NOTE_RULES=[[/柠檬|佛手柑|柑橘|橘|葡萄柚|柚子|bergamot|citrus|lemon/i,[.7,.3,.55,.6,1,.6]],[/薰衣草|lavender/i,[.65,1,.4,.5,.3,.4]],[/迷迭香|薄荷|罗勒|鼠尾草|茶|rosemary|mint|sage|tea/i,[1,.65,.5,.45,.7,.65]],[/玫瑰|茉莉|橙花|依兰|牡丹|晚香玉|紫罗兰|鸢尾|小苍兰|百合|天竺葵|金合欢|铃兰|rose|jasmine|neroli/i,[.3,.6,.6,1,.45,.65]],[/雪松|檀香|岩兰草|香根草|柏|木|cedar|sandal|vetiver/i,[.8,.85,.85,.45,.3,.5]],[/肉桂|胡椒|豆蔻|姜|cinnamon|pepper|cardamom|ginger/i,[.5,.3,1,.55,.85,.7]],[/香草|麝香|琥珀|安息香|豆|vanilla|musk|amber/i,[.3,.9,.55,.85,.3,.45]],[/乳香|没药|焚香|广藿香|incense|myrrh|patchouli/i,[.75,.8,.8,.35,.3,.8]],[/海盐|海洋|矿|水生|水感|sea|marine/i,[.6,.75,.45,.65,.8,.65]]];
const norm=x=>((x%360)+360)%360;
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const rad=x=>x*Math.PI/180;
function sign(lon){const i=Math.floor(norm(lon)/30);return {index:i,name:SIGNS[i],glyph:GLYPHS[i],element:ELEMENTS[i%4],degree:norm(lon)%30,longitude:norm(lon)};}
function finite(value,label,min,max){if(value===''||value===null||value===undefined||!Number.isFinite(Number(value))||Number(value)<min||Number(value)>max)throw Error(label+'超出有效范围');return Number(value);}
function birthChart(input,A){
 if(!A)throw Error('星位计算模块未加载，请刷新页面。');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(input.date||''))throw Error('请填写出生年月日。');
 const [year,month,day]=input.date.split('-').map(Number);const utcTest=new Date(Date.UTC(year,month-1,day));
 if(utcTest.getUTCFullYear()!==year||utcTest.getUTCMonth()!==month-1||utcTest.getUTCDate()!==day||year<1900||utcTest>new Date())throw Error('请填写 1900 年至今天之间的有效出生日期。');
 const offset=finite(input.offset,'出生时 UTC 时差',-12,14);
 const complete=!!input.time;
 let h=12,m=0;
 if(complete){if(!/^\d{2}:\d{2}$/.test(input.time))throw Error('出生时间格式应为 HH:MM');[h,m]=input.time.split(':').map(Number);if(h>23||m>59)throw Error('出生时间无效');}
 const date=new Date(Date.UTC(year,month-1,day,h,m)-offset*3600000);
 const sun=sign(A.SunPosition(date).elon);
 const chart={sun,moon:null,asc:null,complete,utc:date.toISOString(),uncertain:false,warnings:[],placements:[]};
 if(!complete){
   const a=sign(A.SunPosition(new Date(Date.UTC(year,month-1,day)-offset*3600000)).elon),b=sign(A.SunPosition(new Date(Date.UTC(year,month-1,day,23,59)-offset*3600000)).elon);
   chart.uncertain=a.index!==b.index;chart.candidates=[...new Set([a.name,b.name])];
   chart.warnings.push(chart.uncertain?'当天太阳换座，可能为'+chart.candidates.join(' / ')+'；补充时间前关闭星座加权。':'仅日期模式：按出生地中午估算太阳，不推断月亮或上升。');
 }else{
   const lat=finite(input.lat,'纬度',-89.9,89.9),lon=finite(input.lon,'经度',-180,180);
   chart.moon=sign(A.EclipticGeoMoon(date).lon);
   if(Math.abs(lat)>=66){chart.warnings.push('极区上升点存在特殊几何情况，此版不计算上升。');}
   else {const theta=rad(norm(A.SiderealTime(date)*15+lon)),eps=rad(A.e_tilt(new A.AstroTime(date)).tobl);chart.asc=sign(norm(Math.atan2(-Math.cos(theta),Math.sin(theta)*Math.cos(eps)+Math.tan(rad(lat))*Math.sin(eps))*180/Math.PI+180));}
   chart.placements=[['太阳','Sun'],['月亮','Moon'],['水星','Mercury'],['金星','Venus'],['火星','Mars'],['木星','Jupiter'],['土星','Saturn'],['天王星','Uranus'],['海王星','Neptune'],['冥王星','Pluto']].map(([name,body])=>({bodyName:name,...sign(A.Ecliptic(A.GeoVector(body,date,true)).elon)}));
   chart.warnings.push('热带黄道、地心星位、传统七曜守护与整宫制。推荐结合金星、月亮、太阳、命主星、主要相位和目标相关宫主星。');
 }
 return ASTRO.enrichChart(chart,A);
}
function allNotes(p){return [...new Set(Object.values(p.notes||{}).flat().filter(x=>typeof x==='string'))];}
function profile(p){
 let v=[.25,.25,.25,.25,.25,.25],count=0;
 for(const [re,values] of NOTE_RULES){if(re.test(allNotes(p).join(' '))){v=v.map((x,i)=>x+values[i]);count++;}}
 if(count)v=v.map(x=>x/(count+1));
 Object.keys(TAGS).forEach((tag,i)=>{if((p.tags||[]).includes(tag))v[i]=Math.max(v[i],.9);});
 return v;
}
function affinity(v,target){return target.reduce((s,x,i)=>s+x*v[i],0)/target.reduce((a,b)=>a+b,0);}
function astroVector(chart){if(chart.uncertain)return [.6,.6,.6,.6,.6,.6];let sum=0,v=[0,0,0,0,0,0];[['sun',.5],['moon',.3],['asc',.2]].forEach(([key,w])=>{if(chart[key]){sum+=w;v=v.map((x,i)=>x+w*ELEMENT_VECTORS[chart[key].element][i]);}});return v.map(x=>x/sum);}
function classifyText(text,fallback,type){
 const rules=type==='goal'?[[/创业|融资|事业|生意|公司|startup|business|entrepreneur|fundrais/i,'startup'],[/恋爱|感情|关系|relationship|romance|connection/i,'relationship'],[/学习|考试|考研|成长|研究|博士|learning|growth|exam|study|academic|research|phd/i,'growth'],[/休息|放松|状态|休养|reset|rest|relax|recover/i,'reset']]:[[/面试|答辩|interview/i,'interview'],[/客户|谈判|商务|client|negotiat|business meeting/i,'client'],[/约会|相亲|\bdate\b|dating/i,'date'],[/路演|演讲|汇报|presentation|pitch/i,'presentation'],[/写作|论文|学习|图书馆|实验室|writing|thesis|study|deep work|library/i,'study'],[/创作|艺术|画画|设计|creative|artwork|design|paint/i,'creative'],[/聚会|派对|social|party/i,'social']];
 return rules.find(([re])=>re.test(text||''))?.[1]||fallback;
}
function intentVector(key,map,intention){let v=[...(map[key]||map.custom).vector];if(key==='custom'&&TAGS[intention])v[Object.keys(TAGS).indexOf(intention)]=1;return v;}
function scorePerfume(p,ctx){
 const v=profile(p),weights={...WEIGHTS[ctx.level||1]};if(!ctx.useAstro||ctx.chart.uncertain)weights.astro=0;
 const total=Object.values(weights).reduce((a,b)=>a+b,0);Object.keys(weights).forEach(k=>weights[k]/=total);
 const goalKey=classifyText(ctx.goalText,ctx.goal||'growth','goal'),eventKey=classifyText(ctx.eventText,ctx.event||'client','event');
 const preference=preferenceVector(ctx.likes,ctx.feelingText);let pref=preference?affinity(v,preference):.6;
 if((ctx.loved||[]).includes(p.id))pref=clamp(pref+.15);
 const astrology=ASTRO.match(p,ctx.astroTarget||ASTRO.buildTarget(ctx.chart,{...ctx,goalKey,eventKey}));
 const parts={astro:astrology.score,goal:affinity(v,intentVector(goalKey,GOALS,ctx.intention)),event:affinity(v,intentVector(eventKey,EVENTS,ctx.intention)),preference:pref};
 const score=100*Object.keys(weights).reduce((s,k)=>s+weights[k]*parts[k],0);
 return {perfume:p,score:Math.round(score),rawScore:score,parts,weights,goalKey,eventKey,astrology};
}
function rank(catalog,ctx){
 ctx={...ctx,astroTarget:ASTRO.buildTarget(ctx.chart,{...ctx,goalKey:classifyText(ctx.goalText,ctx.goal||'growth','goal'),eventKey:classifyText(ctx.eventText,ctx.event||'client','event')})};
 const excluded=(ctx.exclude||'').split(/[,，、;；]/).map(x=>x.trim().toLowerCase()).filter(Boolean),owned=new Set(ctx.owned||[]);
 const max=ctx.level===3?Math.min(Number(ctx.maxIntensity||3),(EVENTS[classifyText(ctx.eventText,ctx.event,'event')]||EVENTS.custom).max):Number(ctx.maxIntensity||3);
 const pool=catalog.filter(p=>p.recommendable!==false&&(!ctx.ownedOnly||owned.has(p.id))&&!excluded.some(x=>(allNotes(p).join(' ')+' '+(ctx.noteAliases?.[p.id]||'')).toLowerCase().includes(x))&&Number(p.intensity||2)<=max);
 const ranked=pool.map(p=>scorePerfume(p,ctx)).sort((a,b)=>b.rawScore-a.rawScore||a.perfume.id.localeCompare(b.perfume.id));
 const selected=[];const remaining=[...ranked];
 while(selected.length<3&&remaining.length){remaining.sort((a,b)=>{const penalty=x=>selected.reduce((sum,s)=>sum+(s.perfume.brand===x.perfume.brand?3:0)+(s.perfume.family===x.perfume.family?4:0),0);return (b.rawScore-penalty(b))-(a.rawScore-penalty(a));});selected.push(remaining.shift());}
 return {selected,ranked,poolCount:pool.length,maxIntensity:max};
}
function layering(ranked,ctx){
 if(!ctx.allowLayer||ranked.length<2)return null;
 const pool=ranked.slice(0,14);let best=null;
 const officialIds=['jo-malone-wood-sage-sea-salt','jo-malone-lime-basil-mandarin'];
 const official=officialIds.map(id=>ranked.find(r=>r.perfume.id===id));
 if(official.every(Boolean)&&official.reduce((n,r)=>n+r.perfume.intensity,0)<=4){best={items:official.map(r=>r.perfume),shared:[],score:(official[0].rawScore+official[1].rawScore)/2+5,reason:'鼠尾草海盐的木质轮廓与青柠罗勒的柑橘草本形成清新对比',official:true,sourceUrl:'https://www.jomalone.com/scents/woody/wood-sage-sea-salt'};}
 for(let i=0;i<pool.length;i++)for(let j=i+1;j<pool.length;j++){
  const a=pool[i],b=pool[j];if(a.perfume.id===b.perfume.id)continue;
  if(Number(a.perfume.intensity)+Number(b.perfume.intensity)>4)continue;
  const na=allNotes(a.perfume),nb=allNotes(b.perfume),shared=na.filter(n=>nb.includes(n));
  const similar=a.perfume.family!=='自定义香气'&&a.perfume.family===b.perfume.family;
  if(!shared.length&&!similar)continue;
  const score=(a.rawScore+b.rawScore)/2+Math.min(shared.length*2,6)+(similar?1:0);
  if(!best||score>best.score)best={items:[a.perfume,b.perfume],shared,score,reason:shared.length?'以共同的「'+shared.slice(0,2).join('、')+'」作衔接':'两款同属「'+a.perfume.family+'」，风格较接近'};
 }
 return best;
}
return {TAGS,FEELINGS,parseFeelings,preferenceVector,SIGNS,GLYPHS,ELEMENTS,ELEMENT_VECTORS,GOALS,EVENTS,WEIGHTS,NOTE_RULES,ASTRO,skyAt:ASTRO.skyAt,sign,birthChart,allNotes,profile,astroVector,affinity,classifyText,scorePerfume,rank,layering};
});
