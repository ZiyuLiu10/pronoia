# Pronoia — 视觉与双语设计

界面以温暖的纸白、墨灰、淡银紫和极浅鼠尾草色构成。Pronoia 使用斜体衬线字标；编辑式大标题、留白、细线与简洁水平导航建立层级。右上角 中文 / EN 随页面保持可见，手机端导航移到下一行。

按钮与卡片的贝母边缘通过多层 CSS 背景实现：透明细边、象牙白高光、银紫 / 粉米 / 浅绿的微妙虹彩。颜色只承担材质与状态表达；保持可见键盘焦点与减少动画支持。主视觉是悬浮的贝母环状雕塑、透明香水瓶、珍珠月亮与镜面水面。

推荐入口以本命香为默认，阶段性目标和当天场合逐层展开；保留三款推荐、最多两款叠喷、个人香水柜、收藏日程、备份和资料出处。切换语言保留表单状态、筛选、收藏和同一套评分。

## 主视觉资产

- 文件：`assets/pronoia-hero.png`，1536 × 1024，PNG。
- 生成模式：内置 `image_gen`，全新生成，无参考图。
- 未使用品牌商品照片；瓶身为概念艺术中的无标识造型。
- 页面图片与字体不依赖外部 CDN；单文件版嵌入图片。

## 实际生成提示词

```text
Use case: stylized-concept. Asset type: an editorial hero artwork for Pronoia, a refined perfume and personal ritual website. Create a highly sophisticated surreal still life, photorealistic 3D/art photography. An enormous sculptural mother-of-pearl shell ribbon, like a single impossible looping oyster shell with organic ripples, floats above a shallow mirrored water plane. A small pristine unlabeled rectangular clear perfume bottle with a pearlescent orb cap is suspended inside the shell opening. One pearl moon hovering farther above, and a soft distant horizon, dreamlike negative space. Nacre shows subtle interference shades of ivory, pale sage, blush and lilac, exquisite real material microtexture, not shiny cheap plastic. Pale warm-gray seamless environment, luminous diffused daylight, soft caustics, quiet long shadows. Medium-wide horizontal composition roughly 3:2, sculpture occupies central-right area with generous breathing room around it, suitable for a large website art panel. Minimal, gallery-quality, impossible yet serene. NO text, NO lettering, NO logos, NO watermark, NO UI, NO gradients that look like a website mockup, no busy decorative clutter.
```
