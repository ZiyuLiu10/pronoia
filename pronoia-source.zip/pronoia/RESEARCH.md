# Pronoia：分步骤调研与算法规范

核查日期：2026-10-23。版本：Pronoia 研究原型 1.1（双语与视觉更新）。

## 先确定产品边界

这是一种以个人目标为中心的选香仪式。天体位置可以计算；气味偏好需要本人反馈；行星与植物对应属于历史信仰或现代象征。三者不能合并成可验证的“转运功效”。首版没有任何成功概率模型。

本次交付覆盖 10 品牌 × 4 款代表香水、6 项一手心理学研究、17 项香材传统记录。它不是全市场普查或系统综述；后续全线扩库需要逐个版本、地区和改版时间核查。

## 第一步：品牌、系列与香调资料

优先读取品牌官方单品页；同名不同浓度不合并。官网只给关键香调时不补编前中后调。香调是嗅觉描述，不是完整成分表、实际植物含量或单分子清单。强度 1–3、风格与目标标签均为编辑估计。

| 品牌 | 香水 / 版本 | 官方公开香调（中文整理） | 来源 |
| --- | --- | --- | --- |
| L’Artisan Parfumeur 阿蒂仙 | Mûre et Musc · EDT | 关键：黑莓、柠檬、白麝香 | [官方页面](https://www.artisanparfumeur.com/us/en_US/p/mure-et-musc-eau-de-toilette-100ml--000000000065168721) |
| L’Artisan Parfumeur 阿蒂仙 | Passage d’Enfer · EDT | 关键：百合、焚香、白麝香 | [官方页面](https://www.artisanparfumeur.com/us/en_US/p/passage-d-enfer-eau-de-toilette-100ml--000000000065168700) |
| L’Artisan Parfumeur 阿蒂仙 | Premier Figuier · EDT | 关键：无花果叶、无花果、雪松 | [官方页面](https://www.artisanparfumeur.com/us/en_US/p/premier-figuier-eau-de-toilette-100ml--000000000065173232) |
| L’Artisan Parfumeur 阿蒂仙 | La Chasse aux Papillons · EDT | 关键：茉莉、椴树花、橙花 | [官方页面](https://www.artisanparfumeur.com/fr/fr/p/la-chasse-aux-papillons-eau-de-toilette-100-ml--000000000065173187) |
| Le Labo | SANTAL 33 · EDP | 关键：小豆蔻、鸢尾、紫罗兰、檀香、雪松、皮革、麝香 | [官方页面](https://www.lelabofragrances.com/fr/santal-33-147.html) |
| Le Labo | THÉ NOIR 29 · EDP | 关键：佛手柑、无花果、月桂叶、雪松、香根草、麝香、红茶、干草、烟草 | [官方页面](https://www.lelabofragrances.com/th-noir-29-148.html?size=50+ml+%2F+1.7+fl+oz) |
| Le Labo | ANOTHER 13 · EDP | 关键：降龙涎香醚、茉莉、苔藓 | [官方页面](https://www.lelabofragrances.com/another-13-463.html?size=50ml) |
| Le Labo | ROSE 31 · EDP | 关键：千叶玫瑰、孜然、乳香、雪松、琥珀、愈创木、岩蔷薇、麝香 | [官方页面](https://www.lelabofragrances.com/rose-31-146.html) |
| Aesop 伊索 | Tacit · EDP | 前：柚子、罗勒、丁香；中：迷迭香、薄荷、茴香；后：雪松、香根草、琥珀；关键：柚子、香根草、罗勒 | [官方页面](https://www.aesop.com/fragrance/fresh/tacit-eau-de-parfum/FR12.html?dwvar_FR12_size=100+mL+%5E+3.3+fl+oz) |
| Aesop 伊索 | Hwyl · EDP | 前：百里香、榄香脂、粉红胡椒；中：柏树、麂皮、天竺葵；后：香根草、乳香、雪松；关键：柏树、乳香、香根草 | [官方页面](https://www.aesop.com/fragrance/woody/hwyl-eau-de-parfum/FR15.html) |
| Aesop 伊索 | Marrakech Intense · EDP | 前：佛手柑、橙花、茉莉；中：玫瑰、小豆蔻、广藿香；后：檀香、雪松、丁香；关键：丁香、檀香、小豆蔻 | [官方页面](https://www.aesop.com/fragrance/marrakech-intense-eau-de-parfum/FR39.html) |
| Aesop 伊索 | Eidesis · EDP | 前：苦橙叶、黑胡椒、乳香；中：孜然、雪松、乳香；后：檀香、雪松、香根草；关键：黑胡椒、乳香、檀香 | [官方页面](https://www.aesop.com/uk/p/fragrance/opulent/eidesis-eau-de-parfum/) |
| Dior 迪奥 | Sauvage Eau de Parfum · EDP | 前：佛手柑；中：花椒、薰衣草、八角；后：香草、降龙涎香醚；关键：佛手柑、香草、广藿香 | [官方页面](https://www.dior.com/en_us/beauty/products/sauvage-eau-de-parfum-E000000376.html) |
| Dior 迪奥 | Miss Dior Blooming Bouquet · EDT | 前：香豌豆、佛手柑；中：大马士革玫瑰、牡丹；后：白麝香；关键：佛手柑、玫瑰、牡丹、白麝香 | [官方页面](https://www.dior.com/en_int/beauty/products/miss-dior-blooming-bouquet-Y0996612.html) |
| Dior 迪奥 | J’adore Eau de Parfum · EDP | 关键：依兰、大马士革玫瑰、大花茉莉、沙巴茉莉 | [官方页面](https://www.dior.com/en_us/beauty/products/j%E2%80%99adore-eau-de-parfum-C099800245.html) |
| Dior 迪奥 | Gris Dior · EDP | 关键：柑橘、玫瑰、紫罗兰、橡木苔 | [官方页面](https://www.dior.com/en_us/beauty/products/gris-dior-Y0840550.html) |
| Hermès 爱马仕 | Un Jardin sur le Nil · EDT | 关键：青芒果、莲花、西克莫木 | [官方页面](https://www.hermes.com/us/en/product/un-jardin-sur-le-nil-eau-de-toilette-V26993/) |
| Hermès 爱马仕 | Terre d’Hermès · EDT | 关键：葡萄柚、雪松、燧石 | [官方页面](https://www.hermes.com/us/en/product/terre-d-hermes-eau-de-toilette-V107188V0/) |
| Hermès 爱马仕 | Twilly d’Hermès · EDP | 关键：生姜、晚香玉、檀香 | [官方页面](https://www.hermes.com/us/en/product/twilly-d-hermes-eau-de-parfum-V107263V0/) |
| Hermès 爱马仕 | Un Jardin à Cythère · EDT | 关键：禾草、橄榄木、鲜开心果 | [官方页面](https://www.hermes.com/us/en/product/un-jardin-a-cythere-eau-de-toilette-V109288V0/) |
| CHANEL 香奈儿 | COCO MADEMOISELLE · EDP | 关键：橙、茉莉、五月玫瑰、广藿香、香根草 | [官方页面](https://www.chanel.com/us/fragrance/p/116520/coco-mademoiselle-eau-de-parfum-spray/) |
| CHANEL 香奈儿 | CHANCE EAU TENDRE · EDT | 关键：葡萄柚、榅桲、茉莉、白麝香 | [官方页面](https://www.chanel.com/fr/parfums/p/126320/chance-eau-tendre-eau-de-toilette-vaporisateur/) |
| CHANEL 香奈儿 | N°5 · EDP | 前：柑橘；关键：柑橘、五月玫瑰、茉莉、醛香、波旁香草 | [官方页面](https://www.chanel.com/us/fragrance/p/125430/n5-eau-de-parfum-spray/) |
| CHANEL 香奈儿 | BLEU DE CHANEL · EDP | 关键：琥珀香调、麝香香调、雪松、檀香 | [官方页面](https://www.chanel.com/us/fragrance/p/107350/bleu-de-chanel-eau-de-parfum-spray/) |
| Givenchy 纪梵希 | L’Interdit · EDP | 前：佛手柑、鲜姜；中：橙花、沙巴茉莉、晚香玉；后：广藿香、香根草；关键：佛手柑、鲜姜、橙花、沙巴茉莉、晚香玉、广藿香、香根草 | [官方页面](https://www.givenchybeauty.com/int/en/p/l-interdit-P069321.html) |
| Givenchy 纪梵希 | Irresistible · EDP | 前：梨香调、黄葵；中：玫瑰、鸢尾；后：雪松、浅色木质香调；关键：梨香调、黄葵、玫瑰、鸢尾、雪松、浅色木质香调 | [官方页面](https://www.givenchybeauty.com/us/p/irresistible-F10100128.html) |
| Givenchy 纪梵希 | Gentleman Réserve Privée · EDP | 前：佛手柑、威士忌；中：栗子、鸢尾根、安息香；后：雪松、香根草、广藿香；关键：佛手柑、威士忌、栗子、鸢尾根、安息香、雪松、香根草、广藿香 | [官方页面](https://www.givenchybeauty.com/us/p/gentleman-reserve-privee-P011161.html) |
| Givenchy 纪梵希 | Ange ou Démon Le Secret · EDP | 前：蔓越莓；中：茶、茉莉；后：浅色木质香调；关键：蔓越莓、茶、茉莉、浅色木质香调、柠檬、绿茶香调 | [官方页面](https://www.givenchybeauty.com/ca/fr/p/ange-ou-demon-le-secret-F10100004.html) |
| Giorgio Armani 阿玛尼 | Sì Eau de Parfum Intense · EDP Intense | 前：黑加仑果蜜；中：大马士革玫瑰、达瓦纳；后：波旁香草、红茶；关键：黑加仑果蜜、大马士革玫瑰、达瓦纳、波旁香草、红茶 | [官方页面](https://www.armanibeauty.co.uk/perfume/womens-perfumes/si/si-eau-de-parfum-intense-refillable/ww-00745-arm.html) |
| Giorgio Armani 阿玛尼 | My Way · EDP | 前：佛手柑、橙花；中：晚香玉、茉莉；后：雪松、香草、白麝香；关键：佛手柑、橙花、晚香玉、茉莉、雪松、香草、白麝香 | [官方页面](https://www.armanibeauty.co.uk/perfume/womens-perfumes/my-way/my-way-eau-de-parfum---refillable/ww-00343-arm.html) |
| Giorgio Armani 阿玛尼 | Acqua di Gioia · EDP | 前：柠檬、薄荷；中：水茉莉香调；后：雪松、岩蔷薇脂、红糖香调；关键：柠檬、薄荷、水茉莉香调、雪松、岩蔷薇脂、红糖香调 | [官方页面](https://www.giorgioarmanibeauty-usa.com/acqua-di-gioia-eau-de-parfum-duo/3614274339154.html) |
| Giorgio Armani 阿玛尼 | Armani/Privé Thé Yulong · EDT | 关键：青柑橘、绿茶、红茶 | [官方页面](https://www.giorgioarmanibeauty-usa.com/fragrances/armani/prive/les-eaux/armani/prive-the-yulong/A2254.html) |
| Yves Saint Laurent 圣罗兰 | Libre · EDP | 关键：薰衣草、橙花、麝香香调、香草 | [官方页面](https://www.yslbeautyus.com/fragrance/womens-fragrances/libre/libre-eau-de-parfum/3614272648418.html?geo=false) |
| Yves Saint Laurent 圣罗兰 | Black Opium · EDP | 关键：咖啡、白花香调、香草 | [官方页面](https://www.yslbeautyus.com/fragrance/womens-fragrances/black-opium/black-opium-eau-de-parfum/252YSL.html) |
| Yves Saint Laurent 圣罗兰 | Mon Paris · EDP | 关键：红色浆果香调、曼陀罗花香调、白麝香、广藿香 | [官方页面](https://www.yslbeautyus.com/fragrance/womens-fragrances/mon-paris/mon-paris-eau-de-parfum/3614272048447.html) |
| Yves Saint Laurent 圣罗兰 | Y Eau de Parfum · EDP | 关键：鼠尾草、天竺葵、木质香调 | [官方页面](https://www.yslbeautyus.com/fragrance/featured/refillable-fragrance/y-eau-de-parfum/3614274057348.html) |
| Jo Malone London 祖玛珑 | Wood Sage & Sea Salt · Cologne | 前：黄葵籽；中：海盐香调；后：鼠尾草；关键：黄葵籽、海盐香调、鼠尾草 | [官方页面](https://www.jomalone.com/scents/woody/wood-sage-sea-salt) |
| Jo Malone London 祖玛珑 | English Pear & Freesia · Cologne | 前：威廉梨香调；中：小苍兰；后：广藿香；关键：威廉梨香调、小苍兰、广藿香、玫瑰 | [官方页面](https://www.jomalone.co.uk/product/25946/12553/colognes/english-pear-freesia-cologne) |
| Jo Malone London 祖玛珑 | Peony & Blush Suede · Cologne | 前：红苹果香调；中：牡丹香调；后：麂绒香调；关键：红苹果香调、牡丹香调、麂绒香调、茉莉、玫瑰 | [官方页面](https://www.jomalone.co.uk/product/25946/27028/colognes/peony-blush-suede-cologne) |
| Jo Malone London 祖玛珑 | Lime Basil & Mandarin · Cologne | 前：柑橘；中：罗勒；后：琥珀木香调；关键：柑橘、青柠、罗勒、白百里香、琥珀木香调 | [官方页面](https://www.jomalone.co.uk/product/25946/10101/colognes/lime-basil-mandarin-cologne?size=9ml) |

版本差异、三调披露边界、官方链接和核查日完整保存在 [catalog.json](data/catalog.json)。不同地区官网可能更新，现场购买时请核对英文名、浓度和包装。

特别案例：Thé Yulong 的英国页面提及 EDT/EDP 标签过渡，当前条目固定美国 EDT 页面；部分官网的比较表与单品文案不同，本库采用有对应浓度的明确单品说明。

## 第二步：香材的西方象征传统

主要采用 Agrippa《Three Books of Occult Philosophy》第一卷的 1651 英译数字转录，以及 Project Gutenberg 所载 Culpeper《The Complete Herbal》的 1850 后世编订本。这里的“核实”仅指在历史文本中找到该记载，不表示其好运或占星效果成立。

古代焚香不是现代皮肤香水；只整理对应，不提供历史药方、动物材料配方或焚烧操作。原典 cedar、sanders、citron 等名称不能自动对应到现代供应链的某个物种。

| 香材 | 核查到的历史记载 | 本产品的现代仪式解释 | 来源 / 状态 |
| --- | --- | --- | --- |
| 玫瑰 | Agrippa 将玫瑰列为金星焚香。 | 现代仪式设计：提醒自己温和表达、认真倾听；用于关系目标的象征标签。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44（1651 英译转录）](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 肉桂 | Agrippa 将肉桂列入水星芳香材料。 | 现代仪式设计：把温暖辛香当作主动开口、推进下一步的提醒。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 柠檬／枸橼果皮 | Agrippa 将 citron peel 列入水星焚香。 | 现代仪式设计：象征开始前理清要说的三件事；不自动套用于佛手柑。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 乳香 | Agrippa 将乳香对应太阳、狮子座。 | 现代仪式设计：作为上场前确认价值和表达立场的个人提示。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 没药 | Agrippa 的太阳、土星配方及白羊对应均含没药。 | 现代仪式设计：用作复盘、设边界与沉着开始的象征。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 雪松 | Agrippa 将 cedar 列为奉献给 Phoebus 的树。 | 现代仪式设计：象征站稳自己的立场，提示重要谈话前准备充分。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 23](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 檀香 | Agrippa 的 sanders 见金星、火星及处女座对应。 | 现代仪式设计：象征耐心打磨作品和有分寸地接近他人。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapters 28 and 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 薰衣草 | Culpeper 的 Lavender 条目将它归水星。 | 现代仪式设计：提醒自己先整理思路再表达；不将古代医药说法作为疗效。 | [Nicholas Culpeper, The Complete Herbal, Lavender（1850 版，Project Gutenberg 转录）](https://www.gutenberg.org/files/49513/49513-h/49513-h.htm) |
| 迷迭香 | Culpeper 归太阳、白羊；Agrippa 的第 24 章归月亮。 | 现代仪式设计：提示自己返回计划、执行一项明确行动；展示传统分歧。 | [Culpeper, The Complete Herbal, Rosemary（1850 版）；Agrippa, Book I, chapter 24](https://www.gutenberg.org/files/49513/49513-h/49513-h.htm) |
| 接骨木 | Culpeper 将 elder 与 dwarf elder 都归金星。 | 现代仪式设计：作为友善联结与相互照顾的象征；不据此声称驱邪或增运。 | [Culpeper, The Complete Herbal, The Elder Tree / The Dwarf-Elder（1850 版）](https://www.gutenberg.org/files/49513/49513-h/49513-h.htm) |
| 安息香 | Agrippa 将 benzoin 用于木星配方、摩羯座焚香。 | 现代仪式设计：用作长程目标中稳定投入、守住节奏的提示。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 肉豆蔻 | Agrippa 将 nutmeg 对应木星芳香材料。 | 现代仪式设计：象征保持开放，准备好尝试新的合作或学习机会。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 丁香（香辛料） | Agrippa 的丁香见木星芳香材料及太阳、水星配方。 | 现代仪式设计：把辛香当成开会前明确重点与主动交流的提示。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 岩蔷薇树脂／劳丹脂 | Agrippa 的 ladanum 见金星及太阳材料列表。 | 现代仪式设计：象征温暖而有边界的表达，用于重要关系或自我展示。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapters 28 and 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 藏红花 | Agrippa 将 saffron 列入金星芳香材料。 | 现代仪式设计：象征表达欣赏和体面地展现自己。 | [Agrippa, Three Books of Occult Philosophy, Book I, chapter 44](https://esotericarchives.com/agrippa/agripp1b.htm) |
| 茉莉 | 本轮未核实茉莉招财、预知或助恋爱的指定原典。 | 如产品使用温柔、自信或夜间氛围标签，应标明是现代香气叙事，而非古代传统结论。 | 指定说法未核实 |
| 佛手柑 | 本轮未核实佛手柑招财或成功的指定原典；不能直接借用 citron peel 的对应。 | 清新、明亮可用作嗅觉风格描述；幸运标签若采用，应明示为产品自己的仪式设计。 | 指定说法未核实 |

不同传统不是一套统一标准：迷迭香在 Agrippa 与 Culpeper 中存在不同对应；檀香也有多重对应。网页保留差异。此表只作为解释旁注，不额外添加所谓财运、桃花运或学业运功效分。

## 第三步：嗅觉、情绪、记忆与偏好

以下是围绕产品设计问题挑选的一手研究，不是完整系统综述。商业香水是复杂混合物，香调词也可能由其他材料重建；精油或单分子实验不能直接外推到某款成品。

### 1. 个人记忆赋予气味情绪意义

Rachel S. Herz, James Eliassen, Sophia Beland, Timothy Souza，2004。样本：5 名健康、右利手女性。

方法：个人重要记忆的气味与视觉线索、相应对照线索的行为测量及 fMRI 比较。

结果：个人重要气味引发更强的主观情绪反应，并伴随杏仁核与海马区域更强激活。

局限：样本极小且仅女性；研究记忆唤起，未测量考试、面试、恋爱或创业结果；不能证明任一香材具有固定情绪效果。

设计启示：记录用户的美好记忆和不愉快联想。已验证让本人感觉舒适的香水应高于通用香材标签。

来源：[Neuroimaging evidence for the emotional potency of odor-evoked memory](https://pubmed.ncbi.nlm.nih.gov/14670575/)；DOI：10.1016/j.neuropsychologia.2003.08.009。

### 2. 描述和期待会改变同一种气味的体验

Ivan E. de Araujo, Edmund T. Rolls, Maria Inés Velazco, Christian Margot, Isabelle Cayeux，2005。样本：12 名健康、右利手男性，23–35 岁。

方法：事件相关 fMRI；同一种异戊酸与奶酪香气混合刺激，交替标注为奶酪或体味，并设置洁净空气条件。

结果：同一气味被标注为体味时愉悦度更低；部分与奖赏及情绪相关的脑区反应也随标签改变。

局限：样本小且仅男性；特殊实验刺激不能代表商业香水；文字期待不等于现实任务成功。

设计启示：推荐文案使用可核验描述，并把仪式提示明确称为个人意图，避免用保证好运的说法塑造错误期待。

来源：[Cognitive Modulation of Olfactory Processing](https://www.oxcns.org/papers/381_DeAraujo%2BRolls%2B%2B%2B05.pdf)；DOI：10.1016/j.neuron.2005.04.021。

### 3. 柠檬气味的情绪实验与无效结果

Janice K. Kiecolt-Glaser 等，2008。样本：56 名健康成年男女。

方法：随机、交叉、三次实验室访问；分别接触柠檬精油、薰衣草精油与水；比较冷压应激前后，并操纵期待信息。

结果：柠檬条件下积极情绪更高；未可靠改善疼痛评分、心率、血压、唾液皮质醇及多项免疫和皮肤修复指标。

局限：精油、暴露剂量与实验时长特定；不能将结果外推到标有柠檬或佛手柑香调的香水，也不能推断治疗或成功率。

设计启示：柑橘可作为供用户试闻的清新风格候选；实际推荐仍由本人喜欢程度和场合决定。

来源：[Olfactory Influences on Mood and Autonomic, Endocrine, and Immune Function](https://pmc.ncbi.nlm.nih.gov/articles/PMC2278291/)；DOI：10.1016/j.psyneuen.2007.11.015。

### 4. 注意力与记忆结果并非越清醒越好

Mark Moss, Jenny Cook, Keith Wesnes, Paul Duckett，2003。样本：144 名志愿者，迷迭香、薰衣草及无香气三组各 48 人。

方法：随机组间实验；在有精油气味或无气味的小隔间完成计算机认知任务与心情量表；实验目的对参与者隐瞒。

结果：迷迭香组部分记忆指标较好，却有记忆反应变慢；薰衣草组工作记忆及部分反应速度较差。迷迭香组报告更高警觉性。

局限：单次实验、多项指标、气味难以完全盲法；主观警觉不代表所有注意任务改善；不能据此保证含迷迭香香水提高学习成绩。

设计启示：重要面试和学习场景优先使用曾试过且不分心的香气，提供个人试用记录，不设置香材自动提升智力分。

来源：[Aromas of rosemary and lavender essential oils differentially affect cognition and mood in healthy adults](https://pubmed.ncbi.nlm.nih.gov/12690999/)；DOI：10.1080/00207450390161903。

### 5. 个人偏好是推荐的重要输入

Artin Arshamian 等，2022。样本：9 个不同非西方文化群体的 225 人。

方法：对 10 种单分子气味进行愉悦度排序，比较文化、气味身份与个体差异。

结果：研究模型中个体差异、气味身份与文化分别解释约 54%、41%、6% 的排序差异；百分数因取整合计略超 100%。

局限：只有 10 种单分子刺激，不能代表所有复杂香水；个体差异项也包含测量噪声；研究无法区分先天因素与共同学习经历。

设计启示：让用户标记喜欢、不喜欢、熟悉和曾穿着愉快的香水；不要根据文化或星座推断她必然喜欢某种味道。

来源：[The perception of odor pleasantness is shared across cultures](https://ora.ox.ac.uk/objects/uuid%3A2f4cefa9-846d-4235-9c4b-160545ea0b49)；DOI：10.1016/j.cub.2022.02.062。

### 6. 相似的嗅觉基础仍容纳文化差异

Piotr Sorokowski, Michał Misiak, S. Craig Roberts 等，2024。样本：582 人；Hadza、Tsimane’、Yali、波兰及马来西亚五组。

方法：对 15 种气味样本作愉悦度评分，并比较不同生活环境与文化群体。

结果：发现跨文化相似性，也发现无法支持气味偏好完全普遍一致的差异；环境中的气味可接触性值得考虑。

局限：跨文化观察比较不能隔离全部因果因素；样本与刺激不同于 2022 年研究，并非其直接复现。

设计启示：推荐保持可更改与可反馈；熟悉度和个人经验优先于把某类香调固定称为人人舒适。

来源：[Is the perception of odour pleasantness shared across cultures and ecological conditions? Evidence from Amazonia, East Africa, New Guinea, Malaysia and Poland](https://pubmed.ncbi.nlm.nih.gov/38863390/)；DOI：10.1098/rsbl.2024.0120。

## 第四步：可解释的推荐算法

### 4.1 输入与约束

- 出生日期（1900 年至今天）、出生时 UTC 时差；可选出生时间、经纬度。城市仅填充坐标，夏令时由用户核对。
- 层级 1：气味偏好与星盘象征；层级 2：增加阶段目标与希望实现的日期；层级 3：增加重要日程、事件与日期。
- 自有香水、喜爱标记、可接受的气味存在感、不喜欢的香调。
- 不喜欢的香调只按公开词条做字符串排除，不能检测过敏原。
- 日期用于规划和保存，不计算流年、行运、吉日或时机成败。

### 4.2 星位计算

使用固定版本 Astronomy Engine 2.1.19，在浏览器离线计算热带黄道的地心星位。太阳取 SunPosition；月亮取 EclipticGeoMoon；行星用 GeoVector → Ecliptic。上升根据当地恒星时、当日真黄赤交角与纬度计算东侧地平线和黄道的交点。

仅日期模式以出生地当地中午为代表，并比较当天开始与结束时的太阳星座。如发生换座，显示两个候选并将星盘权重设为 0。该模式不输出月亮、上升或完整行星表。完整时间模式在 |纬度| ≥66° 时不计算上升，保留提示。

上升实现经独立的 Astronomy Engine 坐标旋转与地平高度检查：测试样例结果位于东侧地平线。未声称提供宫位、相位、行运或专业占星解读。

参考：[Astronomy Engine 编程文档](https://github.com/cosinekitty/astronomy/blob/v2.1.19/source/js/README.md)、[上升点讨论](https://github.com/cosinekitty/astronomy/discussions/340)。

### 4.3 气味与目标向量

六个维度固定为：专注、安定、自信、亲和、活力、灵感。`core.js` 的 NOTE_RULES 包含柑橘、草本/茶、花香、木质、辛香、柔和琥珀麝香、树脂等规则组。这是编辑风格模型，不是香材效果实证矩阵。

匹配到 N 个香调组时，香水各维度为 `(0.25 + Σ组向量值) / (N + 1)`；未匹配时各维度为 0.25。编辑目标标签对应维度取 `max(当前值, 0.9)`。用户自填香水使用相同规则，并明确标注资料未经品牌核实。

目标与事件向量是 0–1 的设计参数。比如申博强调专注、安定、自信；创业强调自信、行动感、亲和与灵感；客户面谈强调亲和、自信与专注。自由文字按明确关键词匹配，未知文字沿用下拉分类，自定义类别用手选核心感觉。

匹配函数 `affinity(V,T) = Σ(V_i × T_i) / ΣT_i`。个人偏好项是已选感觉对应维度的均值；没选则为 0.6；“喜欢这款”加 0.15，上限 1。

星盘向量的元素对应为现代产品设定：火偏活力/自信，土偏专注/安定，风偏灵感/亲和，水偏安定/亲和。太阳、月亮、上升贡献 0.5/0.3/0.2，缺失项重新归一化。其他七行星仅展示。

| 模式 | 星盘象征 A | 目标 G | 场合 E | 偏好 P |
| --- | ---: | ---: | ---: | ---: |
| 本命香 | 0.50 | 0 | 0 | 0.50 |
| 阶段心愿 | 0.25 | 0.50 | 0 | 0.25 |
| 重要一天 | 0.15 | 0.25 | 0.40 | 0.20 |

`score = round(100 × (wA·A + wG·G + wE·E + wP·P))`。关闭星盘或太阳换座未确定时令 wA=0，其余权重归一化。所有分数都是规则分，不能解读为成功概率或实验效果量。

### 4.4 选择三款

先按 ownedOnly、排除香调、最大存在感筛选。学习/面试/客户/约会/演讲/其他事件默认强度 ≤2；创作和聚会可至 3，仍服从用户更低的上限。没有候选时显示空态，最多只返回实际存在的三款。

按分数排序后贪心选取，已选中同品牌者每次扣 3 个排序点，同香型扣 4 点，以减少重复。展示的原始规则分保持不变，故不保证卡片按分数严格递减。规则确定性执行，不随机制造“新运势”。

### 4.5 最多两款叠喷

在通过筛选的最高分前 14 款中枚举两个不同 ID；要求强度之和 ≤4，且有相同公开香调或相同编辑香型。两个“自定义香气”不因这个通用名称而自动算同香型。组合分为两款原始规则分均值 + min(2×共同香调数,6) + 同香型的 1 分。

另将通过同一筛选的 Jo Malone 鼠尾草与海盐 + 青柠罗勒与柑橘作为官方配对候选，组合分为两款规则分均值 +5。这 5 分只是“有品牌配对依据”的编辑优先级，不是效果量。品牌依据：[Wood Sage & Sea Salt 系列页](https://www.jomalone.com/scents/woody/wood-sage-sea-salt)。

取候选中最高组合分，或返回无叠喷建议。不增加第三款。优先分别试香，再比较两张试香纸靠近的体验；不将两个象征相加成“双倍好运”。网页明确区分品牌建议与未经实测的编辑组合。

### 4.6 示例

演示资料 1998-05-16、UTC+8，只提供日期时太阳位于金牛座；加入 10:30 与上海坐标后，月亮约摩羯 17°，上升约狮子 11°。这些星位只为演示，不是用户的出生资料。申博 + 面试 + 偏好专注/安定，往往选择草本、茶、木质等编辑画像较接近的款式。推荐会随个人喜爱标记、筛选和自有香水改变。

## 上线后的验证路线

1. 产品可用性：是否理解三层输入、能否找到已有香水、是否看懂来源和“不保证好运”的边界。
2. 气味盲试：记录喜欢程度、舒适度、是否分心、场合是否合适；先不展示星盘与功效式标签，以减少期待偏差。
3. 个性化对照：比较纯个人偏好、场合规则、增加象征叙事后的满意度与复用率；逐步校准，而非把未验证权重称为智能科学模型。
4. 双香实测：记录具体产品版本、用量、试香纸/衣物/皮肤、时间与结果，保留不喜欢或冲突的组合。
5. 不以 offer、融资、考试或恋爱结果证明香水的因果作用；这些受大量其他因素影响。

## 已知限制与未完成范围

- 数据为 40 款代表样本，不包含点名品牌的全部系列或实时在售状态。
- 心理学研究为问题导向选读，不是系统综述或香水产品功效评价。
- 历史对应只核实记载，未核实的茉莉/佛手柑说法明确保留空来源。
- 没有价格/预算、天气、香水实际扩散度测量、用户账号、跨设备云同步或自动日程提醒。
- 没有专业宫位/相位/行运；历史时区依赖用户填写，不能通过生日猜月亮与上升。
- 叠喷除注明品牌建议外没有成品实测记录；始终最多两款。
- 用户收藏保存在本浏览器；出生资料不默认持久化。个人导出备份不应提交公开仓库。

## 源码与数据的可复核性

资料源链接逐条保存在 [catalog.json](data/catalog.json) 和 [evidence.json](data/evidence.json)。完整计算规则在 [core.js](core.js)，可运行测试在 [tests/core.test.cjs](tests/core.test.cjs)。当前人工与自动验证记录见 [QA.md](QA.md)。

## Pronoia 双语实现补充

显示层可切换中文和英文，算法使用相同原始数据与同一组权重，切换语言不重新定义香水画像。英文翻译按稳定 ID 放在 data/en.json；香调别名同时参与搜索和排除。自由输入关键词已补充 business、growth、relationship、deep work、creative 等英文类别。无法识别时继续使用下拉选项。个人输入不通过远端翻译服务，保持原文。


## 2026-10-23 扩展图鉴

基础资料现为 16 品牌、200 款独立香水版本。新增 Etat Libre d’Orange、BDK、Maison Crivelli、Essential Parfums、Amouage、Parfums de Marly 共 160 款。逐条前中后调或关键材料、浓度和官网来源见 data/catalog.json；真实图片出处见 data/image-credits.json。旧版本中关于 40 款样本的叙述仅代表初版研究范围。研究资料保留在源码中，网页不显示“灵感与依据”栏目。
